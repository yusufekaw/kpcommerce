<?php $__env->startSection('content'); ?>
<?php
$halaman_detail = $data['halaman_detail'];
?>

<div id="blog-page-contain">
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-sm-8"> 
        
        <!-- left block Start  -->
        <div id="left">
          <div class="single-post-item">
            <div class="single-post-details">
              <div class="post-title">
                <h4><a href="#"><?php echo e($halaman_detail->judul); ?></a></h4>
              </div>
              <div class="description">
                <?php echo $halaman_detail->konten; ?>

              </div>
            </div>
          </div>
        </div>
        <!-- left block end  --> 
      </div>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('toko.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projek\htdocs\kpcok\resources\views/toko/halaman/detail.blade.php ENDPATH**/ ?>