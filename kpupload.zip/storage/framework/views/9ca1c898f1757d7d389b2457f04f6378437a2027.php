<?php
$halaman = $data['halaman'];
?>
<!-- Main menu Start -->
<div id="main-menu">
  <div class="container">
    <nav class="navbar navbar-default">
      <div class="navbar-header">
        <button aria-controls= "navbar" data-target="#navbar" data-toggle="collapse" class="navbar-toggle collapsed" type="button"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        <a href="#" class="navbar-brand">menu</a> </div>
      <div class="navbar-collapse collapse" id="navbar">
        <ul class="nav navbar-nav">
          <li><a href="<?php echo e(url('/')); ?>">Beranda</a></li>
          <?php $__currentLoopData = $halaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $halaman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
          $judul = $halaman->judul;
          $judul = str_replace(" ", "_", $judul)
          ?>
          <li><a href="<?php echo e(url('halaman/'.$halaman->id_halaman.'/judul/'.$judul)); ?>"><?php echo e($halaman->judul); ?></a></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <li><a href="<?php echo e(url('halaman/tentang')); ?>">Tentang Kami</a></li>
          <li><a href="<?php echo e(url('halaman/kontak')); ?>">Kontak Kami</a></li>
        </ul>
      </div>
    </nav>
  </div>
</div>
<!-- Main menu End --> <?php /**PATH D:\projek\htdocs\kpcok\resources\views/toko/layouts/menu.blade.php ENDPATH**/ ?>