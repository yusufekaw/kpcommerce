<h1>Hi, <?php echo e($name); ?>!</h1>
<p>Pesanan kamu sudah kami kirim. Semoga selamat sampai tujuan</p><?php /**PATH D:\projek\htdocs\kpcok\resources\views/toko/mail/kirim.blade.php ENDPATH**/ ?>