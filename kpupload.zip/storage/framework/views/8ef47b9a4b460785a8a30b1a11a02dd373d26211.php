<!-- top navigation -->
<?php
  $order = $data['order'];
  $komentar = $data['komentar_all'];
  $order_count = $data['order_count'];
  $koment_count = $data['komentar_count'];
?>
<div class="top_nav">
  <div class="nav_menu">
    <nav>
      <div class="nav toggle">
        <a id="menu_toggle"><i class="fa fa-bars"></i></a>
      </div>

      <ul class="nav navbar-nav navbar-right">
        <li class="">
          <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
            <img src="<?php echo e(asset(Auth::user()->avatar)); ?>" alt=""><?php echo e(Auth::user()->nama_depan.' '.Auth::user()->nama_belakang); ?>

            <span class=" fa fa-angle-down"></span>
          </a>
          <ul class="dropdown-menu dropdown-usermenu pull-right">
            <li><a href="<?php echo e(url('admin/useradmin/login/profil')); ?>">Profil<i class="fa fa-user pull-right"></i></a></li>
            <li><a href="<?php echo e(url('admin/useradmin/login/edit')); ?>">Edit Profil<i class="fa fa-pencil pull-right"></i></a></li>
            <li><a href="<?php echo e(url('admin/useradmin/login/password/edit')); ?>">Ganti Password<i class="fa fa-edit pull-right"></i></a></li>
            <li><a href="<?php echo e(route('logout')); ?>"
                     onclick="event.preventDefault();
                                   document.getElementById('logout-form').submit();"><i class="fa fa-sign-out pull-right"></i> Log Out</a>
            </li>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
          </ul>
        </li>

        <li role="presentation" class="dropdown">
          <a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown" aria-expanded="false">
            <i class="fa fa-shopping-cart"></i>
            <span class="badge bg-green"><?php echo e($order_count); ?></span>
          </a>
          <ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu">
            <li>
              <div class="text-center">
               <a>
                <strong>Ada <?php echo e($order_count); ?> order yang harus segera dilayani</strong>
                 <i class="fa fa-angle-right"></i>
               </a>
             </div>
            </li>
            <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
              <a href="<?php echo e(url('admin/order/detail/'.$order->id_order)); ?>">
                <span class="image"><img src="<?php echo asset($order->avatar); ?>" alt="Profile Image" /></span>
                <span>
                  <span><?php echo e($order->nama_depan.' '.$order->nama_belakang); ?></span>
                  <span class="time"></span>
                </span>
                <span class="message">
                  ID order : <?php echo e($order->id_order); ?>

                </span>
              </a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <li>
             <div class="text-center">
               <a>
                <strong>Lihat Semua Order</strong>
                 <i class="fa fa-angle-right"></i>
               </a>
             </div>
           </li>
          </ul>
        </li>

        <li role="presentation" class="dropdown">
          <a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown" aria-expanded="false">
            <i class="fa fa-comments"></i>
            <span class="badge bg-green"><?php echo e($koment_count); ?></span>
          </a>
          <ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu">
            <?php $__currentLoopData = $komentar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komentar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
              <a href="<?php echo e(url('admin/produk/detail/'.$komentar->id_produk)); ?>">
                <span class="image"><img src="<?php echo e(asset($komentar->avatar)); ?>" alt="Profile Image" /></span>
                <span class="image"><img src="<?php echo e(asset($komentar->gambar)); ?>" alt="Profile Image" /></span>
                <span>
                  <span><?php echo e($komentar->nama); ?> -> <?php echo e($komentar->produk); ?></span>
                  <span class="time"></span>
                </span>
                <span class="message">
                  <?php echo e($komentar->komentar); ?>

                </span>
              </a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </li>

      </ul>
    </nav>
  </div>
</div>
        <!-- /top navigation --><?php /**PATH D:\projek\htdocs\kpupload\resources\views/admin/layout/navbar.blade.php ENDPATH**/ ?>