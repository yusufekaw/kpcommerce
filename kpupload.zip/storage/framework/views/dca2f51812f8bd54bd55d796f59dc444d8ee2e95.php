<?php $__env->startSection('content'); ?>
<?php 
$halaman = $data['halaman'];
?>
<div class="right_col" role="main">
  <div class="page-title">
    <div class="title_left">
      <h3>Halaman</h3>
    </div>
  </div>

  <div class="clearfix"></div>
 
<div class="row">
	<div class="col-md-12 col-sm-12">
		<?php if(session()->get('success')): ?>
		<div class="alert alert-success alert-dismissible">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			<?php echo e(session()->get('success')); ?>  
		</div>
		<?php endif; ?>
		<div class="x_panel">
		  <div class="x_title">
		    <h2>Baca Halaman</h2>
		    <ul class="nav navbar-right panel_toolbox">
		      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
		      </li>
		      <li class="dropdown">
		        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
		        <ul class="dropdown-menu" role="menu">
		          <li><a href="#">Settings 1</a>
		          </li>
		          <li><a href="#">Settings 2</a>
		          </li>
		        </ul>
		      </li>
		      <li><a class="close-link"><i class="fa fa-close"></i></a>
		      </li>
		    </ul>
		    <div class="clearfix"></div>
		  </div>
		  <div class="x_content">
		  <table id="datatable-responsive" class="table table-striped dt-responsive nowrap" cellspacing="0" width="100%">
		      <tbody>
		    	<tr>
		    		<th>
		    			<?php echo e($halaman->judul); ?>

		    		</th>
		    		<td>
		    			<a href="<?php echo e(url('admin/halaman/edit/'.$halaman->id_halaman)); ?>" class="btn btn-warning"><i class="fa fa-edit"></i></a>
		    			<a href="<?php echo e(url('admin/halaman/delete/'.$halaman->id_halaman)); ?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>
		    		</td>
		    	</tr>
		    	<tr>
		    		<td colspan="3"><?php echo $halaman->konten; ?></td>
		    	</tr>
		      </tbody>
		    </table>


		  </div>
		</div>
	</div>
</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projek\htdocs\kpcok\resources\views/admin/halaman/detail.blade.php ENDPATH**/ ?>