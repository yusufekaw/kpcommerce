<?php $__env->startSection('content'); ?>

	<?php echo $__env->make('beautymail::templates.widgets.articleStart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
$total_harga = 0;
?>
<h1>hi <?php echo e($nama); ?></h1>
<p>Terimakasih udah belanja di CV BENSON</p>
<p>Berikut ini adalah daftar pesanan kamu dengan ID <?php echo e($id_order); ?> :</p>
<table>
	<tr>
		<th>Produk</th>
		<th>Harga</th>
		<th>Kuantiti</th>
		<th>Total</th>
	</tr>
	<?php $__currentLoopData = $order_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td>&nbsp;&nbsp;<?php echo e($item->nama_produk); ?></td>
		<td>&nbsp;&nbsp;Rp. <?php echo e(number_format($item->harga,2,',','.')); ?></td>
		<td>&nbsp;&nbsp;<?php echo e($item->qty); ?></td>
		<td>&nbsp;&nbsp;Rp. <?php echo e(number_format($item->total_harga,2,',','.')); ?></td>
	</tr>
	<?php $total_harga+=$item->total_harga ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td colspan="3">&nbsp;&nbsp; Total Harga Produk</td>
		<td>&nbsp;&nbsp;Rp. <?php echo e($total_harga); ?></td>
	</tr>
	<tr>
		<td colspan="2">&nbsp;&nbsp; Metode Pengriman</td>
		<td>&nbsp;&nbsp; <?php echo e($metode_kirim->kurir.' '.$metode_kirim->layanan); ?></td>
		<td>&nbsp;&nbsp;Rp. <?php echo e(number_format($metode_kirim->tarif,2,',','.')); ?></td>
	</tr>
	<tr>
		<td colspan="3">&nbsp;&nbsp; Total Pembayaran</td>
		<td>&nbsp;&nbsp;<strong>Rp. <?php echo e(number_format($total_harga+$metode_kirim->tarif,2,',','.')); ?></strong></td>
	</tr>
</table>

<p>
	<strong>Dikirim ke : </strong>
	<?php echo e($pengiriman->atas_nama.' '.$pengiriman->rt.' '.$pengiriman->rw.' '.$pengiriman->kelurahan.' '.$pengiriman->kecamatan.' '.$pengiriman->kota); ?>

</p>
<p>Bisa di bayar ke :</p>
<table>
	<?php $__currentLoopData = $bank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($bank->nama_bank); ?> <?php echo e($bank->rekening); ?> <br> A/N <?php echo e($bank->atas_nama); ?></td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

<p> udah bayar? jangan lupa konfirmasi biar pesananmu segera kami proses </p>
<a href="<?php echo e(url('pembayaran/konfirmasi/'.$id_order)); ?>">
	pembayaran/konfirmasi/'<?php echo e($id_order); ?>

</a>

	<?php echo $__env->make('beautymail::templates.widgets.articleEnd', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('beautymail::templates.widgets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projek\htdocs\kpcok\resources\views/toko/mail/konfirmasi_order.blade.php ENDPATH**/ ?>