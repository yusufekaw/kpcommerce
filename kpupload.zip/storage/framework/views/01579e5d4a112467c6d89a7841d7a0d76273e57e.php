<?php
$kategori = $data['kategori'];
?>
<div class="col-md-3 col-sm-4"> 
  <!-- left block Start  -->
  <div id="left">
    <div class="sidebar-block">
      <div class="sidebar-widget Category-block">
        <div class="sidebar-title">
          <h4> Kategori </h4>
        </div>
        <ul class="title-toggle">
          <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
            $nama_kategori = $kategori->nama_kategori;
            $nama_kategori = str_replace(' ','_',$nama_kategori); 
          ?>
          <li><a href="<?php echo e(url('produk/kategori/'.$kategori->id_kategori.'/nama/'.$nama_kategori)); ?>"><?php echo e($kategori->nama_kategori); ?></a></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
     
      
      

    </div>
  </div>
  <!-- left block end  --> 
</div><?php /**PATH D:\projek\htdocs\kpcok\resources\views/toko/layouts/sidemenu.blade.php ENDPATH**/ ?>