<?php $__env->startSection('content'); ?>
<?php
$keranjang = $data['keranjang']
?>

<!-- offer block Start  -->
  <div id="offer">
    <div class="container">
      <div class="offer">
        <p>Mumpung masih di keranjang belanja, kamu bisa balikin barang-barang yang gak jadi kamu beli. Karena kalau udah checkout, barang yang udah kamu beli gak bisa dibalikin lagi!</p>
      </div>
    </div>
  </div>
  <!-- offer block end  --> 
  &nbsp;
  <?php echo $__env->make('toko.layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- bredcrumb and page title block start  -->
  <div id="bread-crumb">
    <div class="container">
      <div class="row">
        <div class="col-md-3 col-sm-3 col-xs-3">
          <div class="page-title">
            <h4>Keranjang Belanja</h4>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- bredcrumb and page title block end  -->


  <form method="post">
    <?php echo csrf_field(); ?>
  <div id="cart-page-contain">
    <div class="container">
      <div class="row">
        <div class="col-md-9 col-xs-12"> 
          <!-- left block Start  -->
          <div class="cart-content table-responsive">
            <table class="cart-table table-responsive" style="width:100%">
              <tbody>
                <tr class="Cartproduct carttableheader">
                  <td style="width:15%"> Product</td>
                  <td style="width:45%">Details</td>
                  <td style="width:10%">QNT</td>
                  <td style="width:15%">Total</td>
                  <td class="delete" style="width:10%">&nbsp;</td>
                </tr>
                <?php 
                  $total_harga = 0; 
                  $berat_total = 0;
                ?>
                <?php $__currentLoopData = $keranjang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keranjangs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                  $nama_produk = $keranjangs->nama_produk;
                  $nama_produk = str_replace(' ','_',$nama_produk);
                ?>
                <input type="hidden" name="id_keranjang[]" value="<?php echo e($keranjangs->id_keranjang); ?>">
                <input type="hidden" name="id_produk[]" value="<?php echo e($keranjangs->id_produk); ?>">
                <input type="hidden" name="id_user[]" value="<?php echo e($keranjangs->id_user); ?>">
                <input type="hidden" name="total_harga[]" value="<?php echo e($keranjangs->total_harga); ?>">
                <input type="hidden" name="harga[]" value="<?php echo e($keranjangs->harga); ?>">
                <input type="hidden" name="berat_total[]" value="<?php echo e($keranjangs->berat_total); ?>">
                <input type="hidden" name="berat[]" value="<?php echo e($keranjangs->berat); ?>">
                <?php
                ?>
                <tr class="Cartproduct">
                 	<td>
                  		<div class="image">
                  			<a href="<?php echo e(url('produk/'.$keranjangs->id_produk.'/nama/'.$nama_produk)); ?>">
                  				<img alt="img" src="<?php echo e($keranjangs->gambar); ?>">
                  			</a>
                  		</div>
                  	</td>
                  	<td>
                  	<div class="product-name">
                      	<h4><a href="<?php echo e(url('produk/'.$keranjangs->id_produk.'/nama/'.$nama_produk)); ?>"><?php echo e($keranjangs->nama_produk); ?> </a></h4>
                    </div>
                    <div class="price"><span>Rp. <?php echo e(number_format($keranjangs->harga,2,',','.')); ?></span></div>
                	</td>
                  	<td class="product-quantity">
                  		<div class="quantity">
                    	<input type="number" size="4" class="input-text qty text" title="Qty" value="<?php echo e($keranjangs->qty); ?>" name="qty[]" min="1" max="<?php echo e($keranjangs->stok); ?>" step="1">
                    	</div>
                    </td>
                  	<td class="price">Rp. <?php echo e(number_format($keranjangs->total_harga,2,',','.')); ?></td>
                  	<td class="delete">
                      <input type="hidden" name="id_delete" value="<?php echo e($keranjangs->id_keranjang); ?>">
                      <input type="hidden" name="url" value="<?php echo e(Request::url()); ?>">
                      <a href="<?php echo e(url('keranjang/hapus/'.$keranjangs->id_keranjang)); ?>" title="Delete"> <i class="glyphicon glyphicon-trash "></i></a>
                    </td>
                    <?php 
                      $total_harga+=$keranjangs->total_harga; 
                      $berat_total+=$keranjangs->berat_total; 
                    ?>
                </tr>
                <tr class="Cartproduct">
                  <td></td>
                  <th>Catatan Pembelian</th>
                  <td colspan="4"> <textarea class="form-control"  name="catatan[]"><?php echo e($keranjangs->catatan); ?></textarea> </td>
                </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
          <div class="cart-bottom">
            <div class="box-footer">
              <div class="pull-left"><a class="btn btn-default" href="<?php echo e(url('/')); ?>"> <i class="fa fa-arrow-left"></i> &nbsp; Belanja lgi </a></div>
              <div class="pull-right">
                <button class="btn btn-default" type="submit" formaction="<?php echo e(url('keranjang/update')); ?>"><i class="fa fa-undo"></i> &nbsp; Perbarui Keranjang</button>
              </div>
            </div>
          </div>
          <!-- left block end  --> 
        </div>
        <div class="col-md-3 col-xs-12"> 
          <!-- right block Start  -->
          <div id="right">
            <div class="sidebar-block">
              <div class="sidebar-widget">
                <div class="sidebar-title">
                  <h4>Ringkasan Belanja</h4>
                </div>
                <div id="order-detail-content" class="title-toggle table-block">
                  <div class="carttable">
                    <table class="table" id="cart-summary">
                      <tbody>
                        <tr>
                          <td>Total pembelian</td>
                          <td class="price">Rp. <?php echo e(number_format($total_harga,2,',','.')); ?></td>
                        </tr>
                        <tr>
                          <td>Berat Total</td>
                          <td class="price"><?php echo e($berat_total); ?> gram</td>
                        </tr>
                        <tr>
                          <td>Ongkos kirim</td>
                          <td class="price"><span class="success">Rp. 0,00 (Belum ditetapkan)</span></td>
                        </tr>
                        <tr>
                          <td> Total Bayar</td>
                          <td id="total-price">Rp. <?php echo e(number_format($total_harga,2,',','.')); ?></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              <div class="checkout"> <button type="submit" formaction="<?php echo e(url('checkout')); ?>" title="checkout" class="btn btn-default ">Proses ke Chekout</button> </div>
            </div>
          </div>
          <!-- left block end  --> 
        </div>
      </div>
    </div>
  </div>
</form>
  &nbsp
<?php $__env->stopSection(); ?>
<?php echo $__env->make('toko.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projek\htdocs\kpupload\resources\views/toko/keranjang/index.blade.php ENDPATH**/ ?>