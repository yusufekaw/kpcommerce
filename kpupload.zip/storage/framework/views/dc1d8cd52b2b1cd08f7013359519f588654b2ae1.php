<?php $__env->startSection('content'); ?>
<?php
$alamat = $data['alamat'];
$id_order = $data['id_order'];
$provinsi = $data['provinsi'];
?>
<div class="wrapar"> 
  <div id="checkout-step-contain">
    <div class="container">
      <div class="account-content checkout-staps">

        <div class="products-order checkout billing-information">
          <div class="checkbox">
            <label>
              <input class="addresses-toggle" type="checkbox" data-target="#my-billing-addresses" data-toggle="collapse" value="">
            Ke alamat yang udah ada </label>
          </div>
          <div class="collapse" id="my-billing-addresses">
            <div class="table-responsive">
              <table class="table table-bordered">
                <tbody>
                  <tr>
                    <th>Name</th>
                    <th>Alamat</th>
                    <th></th>
                  </tr>
                  <?php $__currentLoopData = $alamat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alamat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <form class="billing-info" action="<?php echo e(url('pengiriman/simpan')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <tr>
                      <td><?php echo e($alamat->atas_nama.' ('.$alamat->jenis.')'); ?></td>
                      <?php if($alamat->jalan==null): ?>
                      <td>
                        <?php echo e($alamat->kelurahan.' RT/RW '.$alamat->rt.'/'.$alamat->rw.' kec. '.$alamat->kecamatan.', '.$alamat->nama_kota.', '.$alamat->nama_provinsi.' '.$alamat->kodepos); ?>


                      </td>
                      <?php else: ?>
                      <td>
                        <?php echo e($alamat->jalan.', '.$alamat->kelurahan.' RT/RW '.$alamat->rt.'/'.$alamat->rw.' kec. '.$alamat->kecamatan.', '.$alamat->nama_kota.', '.$alamat->nama_provinsi.' '.$alamat->kodepos); ?>

                      
                      </td>
                      
                      <?php endif; ?>
                      <input type="hidden" name="id_order" value="<?php echo e($id_order); ?>">
                      <input type="hidden" name="id_alamat" value="<?php echo e($alamat->id_alamat); ?>">
                      <input type="hidden" name="id_kota" value="<?php echo e($alamat->id_kota); ?>">
                      <td><button class="btn btn-primary btn-sm" type="submit">&nbsp; Kirim ke alamat ini &nbsp;</button></td>
                    </tr>
                  </form>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
          
          <form method="post" action="<?php echo e(url('pelanggan/alamat/simpan')); ?>">
           <?php echo csrf_field(); ?>
           <input type="hidden" name="id_order" value="<?php echo e($id_order); ?>">
           <input type="hidden" name="ref" value="pengiriman">
           <div class="row">
            <div class="col-md-6 col-sm-12">
              <!-- /input-group -->
              <div class="input-group">
                <input type="text" name="atas_nama" class="form-control" placeholder="Atas Nama *" required>
                <?php if ($errors->has('atas_nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('atas_nama'); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </div>
              <!-- /input-group -->
              <div class="input-group">
                <input type="tel" name="telp" class="form-control" placeholder="Nomor Telepon *" required>
                <?php if ($errors->has('jenis')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('jenis'); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </div>
              <!-- /input-group -->
              <div class="input-group">
                <input type="text" name="jenis" class="form-control" placeholder="Jenis (rumah/kantor/dll) *" required>
                <?php if ($errors->has('telp')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('telp'); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </div>

            </div>
            <div class="col-md-6 col-sm-12">


             <!-- /input-group -->
             <div class="input-group">
              <select name="provinsi" class="form-control">
                <option value="">--Provinsi--</option>
                <?php $__currentLoopData = $provinsi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provinsi => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($provinsi); ?>"> <?php echo e($value); ?></option>   
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <?php if ($errors->has('id_provinsi')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('id_provinsi'); ?>
              <p class="text-danger"><?php echo e($message); ?></p>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>

            <!-- /input-group -->
            <div class="input-group">
              <select name="kota" class="form-control">
               <option>--Kota/Kabupaten--</option>

             </select>
             <?php if ($errors->has('id_kota')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('id_kota'); ?>
             <p class="text-danger"><?php echo e($message); ?></p>
             <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
           </div>

           <!-- /input-group -->
           <div class="input-group">
            <input type="text" name="kecamatan" class="form-control" placeholder="Kecamatan *" required>
            <?php if ($errors->has('kecamatan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('kecamatan'); ?>
            <p class="text-danger"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </div>

          <!-- /input-group --> 
          <div class="input-group">
            <input type="text" name="kelurahan" class="form-control" placeholder="Desa/Kelurahan *" required>
            <?php if ($errors->has('kelurahan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('kelurahan'); ?>
            <p class="text-danger"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </div>

          <!-- /input-group -->

          <!-- /input-group -->
          <div class="input-group">
            <input type="text" name="jalan" class="form-control" placeholder="Jalan ">
          </div>

          <!-- /input-group -->
          <div class="input-group">
            <input type="number" name="rw" min="0" class="form-control" placeholder="RW *" required>
            <?php if ($errors->has('rt')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('rt'); ?>
            <p class="text-danger"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </div>

          <!-- /input-group -->
          <div class="input-group">
            <input type="number" name="rt" min="0"  class="form-control" placeholder="RT *" required>
            <?php if ($errors->has('rw')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('rw'); ?>
            <p class="text-danger"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </div>





          <!-- /input-group -->
          <div class="input-group">
            <input type="text" name="kodepos" class="form-control" placeholder="Kode Pos * " required>
            <?php if ($errors->has('kodepos')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('kodepos'); ?>
            <p class="text-danger"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </div>
          <!-- /input-group -->  
        </div>
        <div class="col-md-12">
          <div class="col-md-12 text-center">
            <button class="btn btn-primary" type="submit"> &nbsp;<i class="fa fa-hdd-o"></i> &nbsp; Kirim ke alamat baru &nbsp; </button>
          </div>
        </div>
      </div>
    </form>
  </div>
</div>
</div>
</div>
</div>

<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="<?php echo e(asset('js/kota.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('toko.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projek\htdocs\kpcok\resources\views/toko/transaksi/pengiriman/index.blade.php ENDPATH**/ ?>