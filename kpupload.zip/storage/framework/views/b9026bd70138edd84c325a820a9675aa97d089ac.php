<!-- footer content -->
<footer>
	<div class="pull-right">
		Projek magang Yusuf, Steven, Agung di CV Benson
	</div>
	<div class="clearfix"></div>
</footer>
<!-- /footer content --><?php /**PATH D:\projek\htdocs\kpcok\resources\views/admin/layout/footer.blade.php ENDPATH**/ ?>