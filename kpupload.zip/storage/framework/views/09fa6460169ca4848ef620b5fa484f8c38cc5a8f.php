<?php $__env->startSection('content'); ?>
<?php
  $jne = $data['jne'];
  $tiki = $data['tiki'];
  $pos = $data['pos'];
  $id_order = $data['id_order'];
  $weight = $data['weight'];
  $id_pengiriman = $data['id_pengiriman'];
  error_reporting(0);
?>
<div class="wrapar"> 
  <div id="checkout-step-contain">
    <div class="container">
      <div class="account-content checkout-staps">
        
          
              <div class="table-responsive">
                <table class="table table-bordered">
                  <tbody>
                  	<tr>
                  		<th colspan="4"> JNE </th>
                  	</tr>
                    <tr>
                      <th>Jenis Layanan</th>
                      <th>Estimasi Pengiriman</th>
                      <th>Total Harga</th>
                      <th>Aksi</th>
                    </tr>
                    <?php for($i=0; $i < count($jne[0]['costs']); $i++): ?>
                    <?php 
                    $layanan = $jne[0]['costs'][$i]['service'];
                    $deskripsi = $jne[0]['costs'][$i]['description'];
                    $estimasi = $jne[0]['costs'][$i]['cost'][0]['etd'];
                    $tarif = $jne[0]['costs'][$i]['cost'][0]['value'];
                    ?>
                    <form method="post" action="<?php echo e(url('pengiriman/metode/simpan')); ?>">
                    	<?php echo csrf_field(); ?>
                      <input type="hidden" name="kurir" value="jne">
                    	<input type="hidden" name="id_order" value="<?php echo e($id_order); ?>">
                    	<input type="hidden" name="layanan" value="<?php echo e($layanan); ?>">
                    	<input type="hidden" name="tarif" value="<?php echo e($tarif); ?>">
                    	<input type="hidden" name="berat" value="<?php echo e($weight); ?>">
                    	<input type="hidden" name="id_pengiriman" value="<?php echo e($id_pengiriman); ?>">
                    	<tr>
                    		<td><?php echo e($layanan); ?><br><?php echo e($deskripsi); ?></td>
                    		<td><?php echo e($estimasi); ?></td>
                    		<td>Rp. <?php echo e(number_format($tarif,2,',','.')); ?></td>
                    		<td><input type="submit" name="kirim" value="kirim"></td>
                    	</tr>
                    </form>

                    <?php endfor; ?>
                    
                  </tbody>
                </table>
              </div>

               <div class="table-responsive">
                <table class="table table-bordered">
                  <tbody>
                  	<tr>
                  		<th colspan="4"> POS </th>
                  	</tr>
                    <tr>
                      <th>Jenis Layanan</th>
                      <th>Estimasi Pengiriman</th>
                      <th>Total Harga</th>
                      <th>Aksi</th>
                    </tr>
                    <?php for($i=0; $i < count($pos[0]['costs']); $i++): ?>
                    <?php 
                    $layanan = $pos[0]['costs'][$i]['service'];
                    $deskripsi = $pos[0]['costs'][$i]['description'];
                    $estimasi = $pos[0]['costs'][$i]['cost'][0]['etd'];
                    $tarif = $pos[0]['costs'][$i]['cost'][0]['value'];
                    ?>
                    <form method="post" action="<?php echo e(url('pengiriman/metode/simpan')); ?>">
                    	<?php echo csrf_field(); ?>
                    	<input type="hidden" name="kurir" value="post">
                      <input type="hidden" name="id_order" value="<?php echo e($id_order); ?>">
                    	<input type="hidden" name="layanan" value="<?php echo e($layanan); ?>">
                    	<input type="hidden" name="tarif" value="<?php echo e($tarif); ?>">
                    	<input type="hidden" name="berat" value="<?php echo e($weight); ?>">
                    	<input type="hidden" name="id_pengiriman" value="<?php echo e($id_pengiriman); ?>">
                    	<tr>
                    		<td><?php echo e($layanan); ?><br><?php echo e($deskripsi); ?></td>
                    		<td><?php echo e($estimasi); ?></td>
                    		<td>Rp. <?php echo e(number_format($tarif,2,',','.')); ?></td>
                    		<td><input type="submit" name="kirim" value="kirim"></td>
                    	</tr>
                    </form>

                    <?php endfor; ?>
                    
                  </tbody>
                </table>
              </div>

            <?php if(count($tiki[0]['costs'])>0): ?>
			       <div class="table-responsive">
                <table class="table table-bordered">
                  <tbody>
                  	<tr>
                  		<th colspan="4"> TIKI </th>
                  	</tr>
                    <tr>
                      <th>Jenis Layanan</th>
                      <th>Estimasi Pengiriman</th>
                      <th>Total Harga</th>
                      <th>Aksi</th>
                    </tr>
                    <?php for($i=0; $i < count($tiki[0]['costs']); $i++): ?>
                    <?php if($i==0): ?>
                    <tr>
                      <td colspan=4>
                        Saat ini tiki gak bisa ngirim ke alamatmu
                      </td>
                    </tr>
                    <?php endif; ?>
                    <?php 
                    $layanan = $tiki[0]['costs'][$i]['service'];
                    $deskripsi = $tiki[0]['costs'][$i]['description'];
                    $estimasi = $tiki[0]['costs'][$i]['cost'][0]['etd'];
                    $tarif = $tiki[0]['costs'][$i]['cost'][0]['value'];
                    ?>
                    <form method="post" action="<?php echo e(url('pengiriman/metode/simpan')); ?>">
                    	<?php echo csrf_field(); ?>
                    	<input type="hidden" name="kurir" value="tiki">
                      <input type="hidden" name="id_order" value="<?php echo e($id_order); ?>">
                    	<input type="hidden" name="layanan" value="<?php echo e($layanan); ?>">
                    	<input type="hidden" name="tarif" value="<?php echo e($tarif); ?>">
                    	<input type="hidden" name="berat" value="<?php echo e($weight); ?>">
                    	<input type="hidden" name="id_pengiriman" value="<?php echo e($id_pengiriman); ?>">
                    	<tr>
                    		<td><?php echo e($layanan); ?><br><?php echo e($deskripsi); ?></td>
                    		<td><?php echo e($estimasi); ?></td>
                    		<td><?php echo e(number_format($tarif,2,',','.')); ?></td>
                    		<td><input type="submit" name="kirim" value="kirim"></td>
                    	</tr>
                    </form>

                    <?php endfor; ?>
                  </tbody>
                </table>
              </div>
              <?php endif; ?>

          </div>
      </div>
    </div>
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('toko.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projek\htdocs\kpupload\resources\views/toko/transaksi/pengiriman/metode.blade.php ENDPATH**/ ?>