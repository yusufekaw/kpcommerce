<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo e($data['title']); ?></title>
<meta content="" name="description">
<meta content="" name="author">

<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('kors-look/images/favicon.ico')); ?>">
<link rel="icon" type="image/png" href="<?php echo e(asset('kors-look/images/favicon.png')); ?>">
<link rel="apple-touch-icon" href="<?php echo e(asset('kors-look/images/favicon.png')); ?>">
<link href="<?php echo e(asset('kors-look/css/jquery-ui.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('kors-look/bootstrap/css/bootstrap.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('kors-look/css/style.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('kors-look/css/font-awesome.css')); ?>" rel="stylesheet" type="text/css">
<link href='https://fonts.googleapis.com/css?family=Poppins:400,500,600,300,700' rel='stylesheet' type='text/css'>
<link href="<?php echo e(asset('kors-look/css/owl.carousel.css')); ?>" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('kors-look/css/smoothproducts.css')); ?>">


</head>
<body>
<div class="wrapar"> 
  <!-- Header Start-->
  <?php echo $__env->make('toko.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- Header End --> 
  
  <!-- Main menu Start -->
  <?php echo $__env->make('toko.layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- Main menu End --> 
 <!-- Content -->
 <?php echo $__env->yieldContent('content'); ?>
 <!--  end  of content -->
  
  <!-- Footer block Start  -->
  <?php echo $__env->make('toko.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- Footer block End  --> 
</div>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 



<script src="<?php echo e(asset('kors-look/js/jQuery.js')); ?>"></script> 
<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="<?php echo e(asset('kors-look/bootstrap/js/bootstrap.js')); ?>"></script> 
<script src="<?php echo e(asset('kors-look/js/jquery-ui.js')); ?>"></script> 
<script src="<?php echo e(asset('kors-look/js/owl.carousel.min.js')); ?>"></script> 
<script src="<?php echo e(asset('kors-look/js/globle.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(asset('kors-look/js/smoothproducts.min.js')); ?>"></script> 
<!-- jQuery (price shorting) --> 
<script>
    $(function() {
        $( "#slider-range" ).slider({
        range: true,
        min: 0,
        max: 800,
        values: [ 75, 500 ],
        slide: function( event, ui ) {
        $( "#amount" ).val( "$" + ui.values[ 0 ] + " - $" + ui.values[ 1 ] );
        }
        });
        $( "#amount" ).val( "$" + $( "#slider-range" ).slider( "values", 0 ) +
        " - $" + $( "#slider-range" ).slider( "values", 1 ) );
        });
    </script> 

    <script type="text/javascript"> 
      $("#tabs li a").click(function(e){
        var title = $(e.currentTarget).attr("title");
        $("#tabs li a").removeClass("selected")
        $(".tab-content li div").removeClass("selected")
        $(".tab-"+title).addClass("selected")
        $(".items-"+title).addClass("selected")
        $("#items").attr("class","tab-"+title);
      });
        $(window).load( function() {
        $('.sp-wrap').smoothproducts();
    });
     </script>


<script src="<?php echo e(asset('kors-look/js/globle.js')); ?>"></script>

 <script src="<?php echo e(asset('js/app.js')); ?>"></script>
 <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
</body>
</html><?php /**PATH D:\projek\htdocs\kpupload\resources\views/toko/layouts/app.blade.php ENDPATH**/ ?>