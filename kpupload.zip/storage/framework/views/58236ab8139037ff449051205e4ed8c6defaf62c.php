<style type="text/css">
.alert-custom{
 	background-color:#d9121f;
	text-align: center;
	color: #ffffff;
}
</style>

<!-- Sukses beli -> masuk keranjang -->
<div id="offer">
	<div class="container">
		<?php if(session()->get('alert')): ?>
           <div class="alert alert-custom alert-dismissible">
           		<button type="button" class="close btn btn-" data-dismiss="alert" aria-hidden="true">&times;</button>
                <?php echo e(session()->get('alert')); ?>

            </div>
         <?php endif; ?>
	</div>
</div>
<!-- akhir sukses beli -->

<!-- Gagal Login -->
<div id="offer">
	<div class="container">
		<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
		<div class="alert alert-custom alert-dismissible">
			<strong><?php echo e($message); ?></strong>
			<button type="button" class="close btn btn-" data-dismiss="alert" aria-hidden="true">&times;</button>
        </div>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
	</div>
</div>

<div id="offer">
	<div class="container">
		<?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
		<div class="alert alert-custom alert-dismissible">
			<strong><?php echo e($message); ?></strong>
			<button type="button" class="close btn btn-" data-dismiss="alert" aria-hidden="true">&times;</button>
        </div>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
	</div>
</div>
<!-- akhir gagal login -->

<!-- Gagal Daftar -->
<div id="offer">
	<div class="container">
		<?php if ($errors->has('nama_depan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_depan'); ?>
		<div class="alert alert-custom alert-dismissible">
			<strong><?php echo e($message); ?></strong>
			<button type="button" class="close btn btn-" data-dismiss="alert" aria-hidden="true">&times;</button>
        </div>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
	</div>
</div>

<div id="offer">
	<div class="container">
		<?php if ($errors->has('nama_belakang')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_belakang'); ?>
		<div class="alert alert-custom alert-dismissible">
			<strong><?php echo e($message); ?></strong>
			<button type="button" class="close btn btn-" data-dismiss="alert" aria-hidden="true">&times;</button>
        </div>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
	</div>
</div>

<div id="offer">
	<div class="container">
		<?php if ($errors->has('gender')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gender'); ?>
		<div class="alert alert-custom alert-dismissible">
			<strong><?php echo e($message); ?></strong>
			<button type="button" class="close btn btn-" data-dismiss="alert" aria-hidden="true">&times;</button>
        </div>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
	</div>
</div>

<div id="offer">
	<div class="container">
		<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
		<div class="alert alert-custom alert-dismissible">
			<strong><?php echo e($message); ?></strong>
			<button type="button" class="close btn btn-" data-dismiss="alert" aria-hidden="true">&times;</button>
        </div>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
	</div>
</div>

<div id="offer">
	<div class="container">
		<?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
		<div class="alert alert-custom alert-dismissible">
			<strong><?php echo e($message); ?></strong>
			<button type="button" class="close btn btn-" data-dismiss="alert" aria-hidden="true">&times;</button>
        </div>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
	</div>
</div>

<div id="offer">
	<div class="container">
		<?php if ($errors->has('konfirmasi_password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('konfirmasi_password'); ?>
		<div class="alert alert-custom alert-dismissible">
			<strong><?php echo e($message); ?></strong>
			<button type="button" class="close btn btn-" data-dismiss="alert" aria-hidden="true">&times;</button>
        </div>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
	</div>
</div>

<!-- akhir gagal daftar -->
<?php /**PATH D:\projek\htdocs\kpcok\resources\views/toko/layouts/alert.blade.php ENDPATH**/ ?>