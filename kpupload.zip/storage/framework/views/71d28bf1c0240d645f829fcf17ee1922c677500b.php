<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title> Panel Admin CVB </title>

    <!-- Bootstrap -->
    <link href="<?php echo e(asset('gentelella/vendors/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo e(asset('gentelella/vendors/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <!-- NProgress -->
    <link href="<?php echo e(asset('gentelella/vendors/nprogress/nprogress.css')); ?>" rel="stylesheet">
    <!-- iCheck -->
    <link href="<?php echo e(asset('gentelella/vendors/iCheck/skins/flat/green.css')); ?>" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="<?php echo e(asset('gentelella/build/css/custom.min.css')); ?>" rel="stylesheet">
  </head>
<?php
$produk = $data['produk'];
$komentar = $data['komentar_all_detail'];
?>
  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            
            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <!--div class="profile clearfix">
              <div class="profile_pic">
                <img src="images/img.jpg" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>Welcome,</span>
                <h2>John Doe</h2>
              </div>
            </div>
            < /menu profile quick info -->

            <!--br /-->

            <!-- sidebar menu -->
            <?php echo $__env->make('admin.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <!--div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="login.html">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div-->
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
            <?php echo $__env->make('admin.layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">

          <div class="">
            <div class="row">
              <div class="col-sm-12">
                <?php if(session()->get('success')): ?>
                <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <?php echo e(session()->get('success')); ?>  
                </div>
                <?php endif; ?>

                <?php if ($errors->has('path')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('path'); ?>
                <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <?php echo e($message); ?>  
                </div>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                <?php if ($errors->has('gambar')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gambar'); ?>
                <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <?php echo e($message); ?>  
                </div>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

              </div>
            </div>
            <div class="page-title">
              <div class="title_left">
                <h3>Detail <?php echo e($produk->nama_produk); ?></h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                  </div>
                </div>
              </div>
            </div>
            
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2><?php echo e($produk->nama_produk); ?></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Settings 1</a>
                          </li>
                          <li><a href="#">Settings 2</a>
                          </li>
                        </ul>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <div class="col-md-4 col-sm-4 col-xs-12">
                      <div class="product-image">
                        <img src="<?php echo e(asset($produk->gambar)); ?>" alt="..." />
                        <form method="post" action="<?php echo e(url('admin/produk/ikon/update/'.$produk->id_produk)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <label class="btn"> Ganti gambar
                            <input type="file" accept="image/*" name="gambar" style="display: none;" onchange="form.submit()">
                        </label>
                        </form>
                      </div>
                      
                    </div>
                    <div class="col-md-8 col-sm-8 col-xs-12" style="border:0px solid #e5e5e5;">

                      <h3 class="prod_title"><?php echo e($produk->nama_produk); ?></h3>

                      <p><?php echo $produk->deskripsi; ?></p>
                      <br />

                      

                      <div class="">
                        <div class="product_price">
                          <h1 class="price">Rp <?php echo e(number_format($produk->harga,2,',','.')); ?></h1>
                          <br>
                        </div>
                      </div>

                      <div class="">
                        <a href="<?php echo e(url('admin/produk/edit/'.$produk->id_produk)); ?>" class="btn btn-default btn-lg btn-warning">
                          <i class="fa fa-edit"></i>
                        </a>
                        <a class="btn btn-default btn-lg btn-danger">
                          <i class="fa fa-trash"></i>
                        </a>
                      </div>

                     

                    </div>
                   
                    <div class="col-md-12 col-sm-12 col-xs-12">
                      <!--div class="product_gallery">
                        
                        <?php $__currentLoopData = $data['gambar_produk']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gambar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                          
                          <a>
                          <span class="badge bg-green">211</span>
                          <span class="badge bg-green">211</span>
                          <img src="<?php echo e(asset($gambar->path)); ?>" style="max-height: 100%;" alt="..." />

                          </a>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div-->
                      <?php $__currentLoopData = $data['gambar_produk']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gambar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <div class="col-md-55">
                        <div class="image view view-first">
                            <img style="max-height: 100%;width: 100%; display: block;" src="<?php echo e(asset($gambar->path)); ?>" alt="image">
                            <div class="mask">
                                <form method="post" action="<?php echo e(url('admin/produk/gambar/update/'.$gambar->id_gambar)); ?>" enctype="multipart/form-data">
                                  <?php echo csrf_field(); ?>
                                  <label>
                                    <a class="btn btn-warning btn-lg ">
                                      <i class="fa fa-pencil"></i>
                                      <input type="file" name="path" accept="image/*" style="display: none;" onchange="form.submit()">
                                    </a>
                                  </label>
                                </form>
                                <a href="<?php echo e(url('admin/produk/gambar/delete/'.$gambar->id_gambar)); ?>" class="btn btn-danger btn-lg "><i class="fa fa-times"></i></a>
                              </div>
                          </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <form method="post" action="<?php echo e(url('admin/produk/gambar/save/')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <label>
                      <a class="btn btn-app">
                        <input type="hidden" name="id_produk" value="<?php echo e($produk->id_produk); ?>">
                      <input type="file" accept="image/*" name="path" style="display: none;" onchange="form.submit();">
                      <i class="fa fa-plus"></i> Tambah Gambar
                    </a>
                    </label>
                    </form>
                    </div>



                    <br>
                  </div>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Komentar <?php echo e($produk->nama_produk); ?></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Settings 1</a>
                          </li>
                          <li><a href="#">Settings 2</a>
                          </li>
                        </ul>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <div class="col-md-12">

                      </hr>
                    <h3>Komentar</h3>


                      <table class="table table-responsive table-stripped">
                        <?php $__currentLoopData = $komentar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komentar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><i class="fa fa-users"></i> <?php echo e($komentar->role); ?></td>
                          <td><i class="fa fa-user"></i> <?php echo e($komentar->nama); ?></td>
                          <td><i class="fa fa-calendar"></i> <?php echo e($komentar->tanggal); ?></td>
                        </tr>
                        <tr>
                          <td colspan="3"><?php echo e($komentar->komentar); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </table>

                      <form method="post" action="<?php echo e(url('produk/komentar/')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                          <div class="col-md-9 col-sm-9 col-xs-12">
                          <input type="hidden" name="id_user" value="<?php echo e(Auth::user()->id_user); ?>">
                          <input type="hidden" name="id_produk" value="<?php echo e($produk->id_produk); ?>">
                          <input type="hidden" name="kode_status" value="2">
                          <input type="hidden" name="status" value="dibaca">
                            <textarea class="resizable_textarea form-control" name="komentar"></textarea>
                          </div>
                        </div>
                        <button type="submit" class="btn btn-default" name="kirim"> Balas Komentar </button>
                      </form>
                      <?php echo $data['komentar_all_detail']->render(); ?>


                  </div>


                    
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
            Gentelella - Bootstrap Admin Template by <a href="https://colorlib.com">Colorlib</a>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="<?php echo e(asset('gentelella/vendors/jquery/dist/jquery.min.js')); ?>"></script>
    <!-- Bootstrap -->
    <script src="<?php echo e(asset('gentelella/vendors/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <!-- FastClick -->
    <script src="<?php echo e(asset('gentelella/vendors/fastclick/lib/fastclick.js')); ?>"></script>
    <!-- NProgress -->
    <script src="<?php echo e(asset('gentelella/vendors/nprogress/nprogress.js')); ?>"></script>

    <!-- Custom Theme Scripts -->
    <script src="<?php echo e(asset('gentelella/build/js/custom.min.js')); ?>"></script>
  </body>
</html><?php /**PATH D:\projek\htdocs\kpcok\resources\views/admin/produk/detail.blade.php ENDPATH**/ ?>