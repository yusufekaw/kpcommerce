<?php $__env->startSection('content'); ?>
<?php
    $bank = $data['bank'];
    $nominal = $data['nominal'];
    $id_order = $data['id_order'];
?>
  <div id="contact-page-contain">
    <div class="container">
    	    <div class="row">
    	      <div class="col-md-offset-2 col-md-8">
    	        <div class="contact-title">
    	          <h2 class="tf">Konfirmasi Pembayaran</h2>
    	          <p class="text-center">Upload bukti pembayaran kamu disini</p>
    	      </div>
    	  </div>
    	</div>
    	<div class="contact-submit">
    	  <form method="post" action="<?php echo e(url('pembayaran/upload')); ?>" enctype="multipart/form-data">
    	     <?php echo csrf_field(); ?>
             <input type="hidden" name="id_order" value="<?php echo e($id_order); ?>">
             <input type="hidden" name="nominal" value="<?php echo e($nominal); ?>">
    	    <div class="col-sm-12">
    	    <div class="input-group">
    	    	<select name="bank_tujuan" class="form-control" required>
                    <option value="">Transfer ke Bank</option> 
                    <?php $__currentLoopData = $bank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($bank->nama_bank.' '.$bank->rekening); ?>"><?php echo e($bank->nama_bank.' '.$bank->rekening); ?></option> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                </select>
            <?php if ($errors->has('bank_tujuan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('bank_tujuan'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
    	    </div>
    	    <div class="input-group">
    	    	<input type="text" name="nama_bank" class="form-control" placeholder="Transfer dari Bank" required>
            <?php if ($errors->has('nama_bank')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_bank'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
    	    </div>
    	    <div class="input-group">
    	    	<input type="text" name="rekening" class="form-control" placeholder="rekening" required>
    	    </div>
            <?php if ($errors->has('rekening')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('rekening'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
    	    <div class="input-group">
    	    	<input type="text" name="atas_nama" class="form-control" placeholder="atas_nama" required>
            <?php if ($errors->has('atas_nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('atas_nama'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>    
    	    </div>
    	    <div class="input-group">
                <input type="text" class="form-control" value="<?php echo e($nominal); ?>" readonly>
    	    </div>
    	    <div class="input-group">
    	    	<input type="file" name="bukti" class="form-control" placeholder="Bukti Transfer" accept="image/*" required>
            <?php if ($errors->has('bukti')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('bukti'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>    
    	    </div>



    	  <div class="col-md-12 text-center">
    	      <button  type="submit" class="btn btn-primary"><i class="fa fa-check"></i> Konfirmasi Bukti Transfer </button>
    	  </div>
    	</div>
    	
    	</form>
    	</div>
    	</div>

    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('toko.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projek\htdocs\kpupload\resources\views/toko/transaksi/pembayaran/konfirmasi.blade.php ENDPATH**/ ?>