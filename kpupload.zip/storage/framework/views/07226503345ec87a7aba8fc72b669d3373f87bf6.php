<?php $__env->startSection('content'); ?>
<?php
$useradmin = $data['useradmin'];
?>
<form method="post" action="<?php echo e(url('admin/useradmin/update/'.$useradmin->id_user)); ?>" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
<div class="right_col" role="main">
  <div class="page-title">
    <div class="title_left">
      <h3>User Admin</h3>
    </div>
  </div>

  <div class="pull-right"> 
    <button type="submit" class="btn btn-success"><i class="fa fa-hdd-o"></i> Simpan Perubahan</button>
  </div>

  <div class="clearfix"></div>
 
<div class="row">
  <div class="col-md-12 col-sm-12">
    <div class="x_panel">
      <div class="x_title">
        <h2>Edit User Admin</h2>
        <ul class="nav navbar-right panel_toolbox">
          <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
          </li>
          <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
            <ul class="dropdown-menu" role="menu">
              <li><a href="#">Settings 1</a>
              </li>
              <li><a href="#">Settings 2</a>
              </li>
            </ul>
          </li>
          <li><a class="close-link"><i class="fa fa-close"></i></a>
          </li>
        </ul>
        <div class="clearfix"></div>
      </div>
      <div class="x_content">
        <div class="form-group">
          <label class="control-label col-md-4 for="nama_depan">Nama Depan <span class="required">*</span>
          </label>
          <div class="col-md-8">
            <input type="text" name="nama_depan" id="nama_depan" value="<?php echo e($useradmin->nama_depan); ?>" required="required" class="form-control col-md-8 col-sm-12">
            <?php if ($errors->has('nama_depan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_depan'); ?>
            <span class="text text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-4" for="nama_belakang">Last Name <span class="required">*</span>
          </label>
          <div class="col-md-8">
            <input type="text" id="nama_belakang" name="nama_belakang" value="<?php echo e($useradmin->nama_belakang); ?>" required="required" class="form-control col-md-8 col-sm-12">
            <?php if ($errors->has('nama_belakang')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_belakang'); ?>
            <span class="text text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-4" for="email">Email <span class="required">*</span>
          </label>
          <div class="col-md-8">
            <input type="email" id="email" name="email" value="<?php echo e($useradmin->email); ?>" required="required" class="form-control col-md-8 col-sm-12">
            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
            <span class="text text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-4" for="gender">Gender <span class="required">*</span>
          </label>
          <div class="col-md-8">
            <div class="radio">
              <label class="">
                <div class="iradio_flat-green" style="position: relative;"><input type="radio" class="flat"  name="gender" value="l" required style="position: absolute; opacity: 0;"><ins class="iCheck-helper" style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; border: 0px none; opacity: 0;"></ins></div> Laki-laki
              </label>
              <label class="">
                <div class="iradio_flat-green" style="position: relative;"><input type="radio" class="flat" name="gender" value="p" required style="position: absolute; opacity: 0;"><ins class="iCheck-helper" style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; border: 0px none; opacity: 0;"></ins></div> Perempuan
              </label>
              <?php if ($errors->has('gender')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gender'); ?>
              <span class="text text-danger"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-4" for="role">Role <span class="required">*</span>
          </label>
          <div class="col-md-8">
            <select id="role" name="role" required="required" class="form-control col-md-8 col-sm-12">
              <option value="admin">Admin</option>
              <option value="superadmin">Super Admin</option>
            </select>
            <?php if ($errors->has('role')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('role'); ?>
            <span class="text text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </div>
        </div>
        

      </div>
    </div>
  </div>
</div>

</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projek\htdocs\kpcok\resources\views/admin/user/edit.blade.php ENDPATH**/ ?>