<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\projek\htdocs\kpcok\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>