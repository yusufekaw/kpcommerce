<?php $__env->startSection('content'); ?>
<?php
$tentang = $data['tentang'];
?>

<div id="blog-page-contain">
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-sm-8"> 
        
        <!-- left block Start  -->
        <div id="left">
          <div class="single-post-item">
            <div class="single-post-details">
              <div class="post-title">
                <h4><a href="#"><?php echo e($tentang->nama_toko); ?> | <small><?php echo e($tentang->tagline); ?></small></a></h4>
              </div>
              <div class="description">
                <?php echo $tentang->deskripsi; ?>

              </div>
            </div>
          </div>
        </div>
        <!-- left block end  --> 
      </div>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('toko.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projek\htdocs\kpcok\resources\views/toko/halaman/tentang.blade.php ENDPATH**/ ?>