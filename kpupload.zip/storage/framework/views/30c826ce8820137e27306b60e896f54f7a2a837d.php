<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-sm-12">
		<div id="contact-page-contain">
		   <div class="container">
		    
		     
		     <div class="contact-submit">
		       <form method="post" action="<?php echo e(url('pelanggan/update/password/'.Auth::user()->id_user)); ?>">
		       	<?php echo csrf_field(); ?>
		         <div class="row">
		           <div class="col-md-12 col-sm-12">
		             <div class="input-group">
		             	<label class="form-control" >Password Lama *</label>
		               <input type="password" name="password_lama" class="form-control" required>
		             </div>
		             <?php if ($errors->has('password_lama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password_lama'); ?>
		             <p class="text-danger"><?php echo e($message); ?></p>
		             <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
		             <?php if(session()->get('error')): ?>
		             <p class="text-danger">
		             	<?php echo e(session()->get('error')); ?>

		             </p>
		             <?php endif; ?>
		           </div>
		           <div class="col-md-12 col-sm-12">
		            <div class="input-group">
		             	<label class="form-control">Password baru *</label>
		               <input type="password" name="password_baru" class="form-control" required>
		            </div>
		            <?php if ($errors->has('password_baru')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password_baru'); ?>
		           	<p class="text-danger"><?php echo e($message); ?></p>
		           	<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
		           </div>
		           <div class="col-md-12 col-sm-12">
		             <div class="input-group">
		             	<label class="form-control">Konfirmasi password *</label>
		               <input type="password" name="konfirmasi_password"  class="form-control" >
		             </div>
		             <?php if ($errors->has('konfirmasi_password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('konfirmasi_password'); ?>
		           	<p class="text-danger"><?php echo e($message); ?></p>
		           	<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
		           </div>
		           <div class="col-md-12">
		             <div class="col-md-12 text-center">
		               <button class="btn btn-primary" type="submit"><i class="fa fa-hdd-o"></i> Update Password</button>
		             </div>
		           </div>
		         </div>
		       </form>
		     </div>
		     
		   </div>
		 </div>
	</div>
</div>
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('toko.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projek\htdocs\kpcok\resources\views/toko/pelanggan/password/edit.blade.php ENDPATH**/ ?>