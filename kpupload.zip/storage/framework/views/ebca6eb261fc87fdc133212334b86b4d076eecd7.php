<?php $__env->startSection('content'); ?>
<!--================login_part Area =================-->
   <!--================login Area =================-->
        <section class="login_area p_100">
            <div class="container">
                <div class="login_inner">
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="login_title">
                                <h2>log in your account</h2>
                                <p>Log in to your account to discovery all great features in this template.</p>
                            </div>
                            <form class="login_form row">
                                <div class="col-lg-12 form-group">
                                    <input class="form-control" type="text" placeholder="Name">
                                </div>
                                <div class="col-lg-12 form-group">
                                    <input class="form-control" type="text" placeholder="User Name">
                                </div>
                                <div class="col-lg-12 form-group">
                                    <div class="creat_account">
                                        <input type="checkbox" id="f-option" name="selector">
                                        <label for="f-option">Keep me logged in</label>
                                        <div class="check"></div>
                                    </div>
                                    <h4>Forgot your password ?</h4>
                                </div>
                                <div class="col-lg-12 form-group">
                                    <button type="submit" value="submit" class="btn update_btn form-control">Login</button>
                                </div>
                            </form>
                        </div>
                        <div class="col-lg-8">
                            <div class="login_title">
                                <h2>Bikin Akun</h2>
                                <p>Gak punya akun, gak bisa belanja lho! Yuks bikin akun sekarang.</p>
                            </div>
                            <form method="post" action="<?php echo e(url('pelanggan/save')); ?>">

                                <?php echo csrf_field(); ?>
  												  	
							  	<div class="form-group row">
    								<label for="nama_depan" class="col-sm-2 col-form-label">Nama depan</label>
							    <div class="col-sm-10">
							      <input type="text" name="nama_depan" id="nama_depan" class="form-control  <?php if ($errors->has('nama_depan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_depan'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Nama Depan" required="required" value="<?php echo e(old('nama_depan')); ?>">
                                    <?php if ($errors->has('nama_depan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_depan'); ?>
                                    <span class="text-danger" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							    </div>
							  	</div>

							  	<div class="form-group row">
    								<label for="nama-belakang" class="col-sm-2 col-form-label">Nama Belakang</label>
							    <div class="col-sm-10">
							      <input type="text" name="nama_belakang" id="nama_belakang" class="form-control <?php if ($errors->has('nama_belakang')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_belakang'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="nama belakang" required="required" value="<?php echo e(old('nama_belakang')); ?>">
                                    <?php if ($errors->has('nama_belakang')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_belakang'); ?>
                                    <span class="text-danger" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							    </div>
							  	</div>

							  	<div class="form-group row">
    								<label for="gender" class="col-sm-3 col-form-label">Jenis Kelamin</label>
							    <div class="col-sm-3">
							      <input class="form-check-input" type="radio" name="gender" id="genderl" value="l" required="required"> 
							      <label class="form-check-label" for="genderl">Laki-laki</label>
							    </div>
							    <div class="col-sm-3">
							      <input class="form-check-input" type="radio" name="gender" id="genderp" value="p" required="required"> <label class="form-check-label" for="genderp">Perempuan</label>
							    </div>
							  	</div>

							  	<div class="form-group row">
    								<label for="email" class="col-sm-2 col-form-label">Email</label>
							    <div class="col-sm-10">
							      <input type="email" name="email" id="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Email" required="required" value="<?php echo e(old('email')); ?>">
                                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="text-danger" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							    </div>
							  	</div>

							  <div class="form-group row">
							    <label for="password" class="col-sm-2 col-form-label">Password</label>
							    <div class="col-sm-10">
							      <input type="password" name="password"  id="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Password" required="required" value="<?php echo e(old('password')); ?>">
                                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                    <span class="text-danger" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							    </div>
							  </div>

							  <div class="form-group row">
							    <label for="konfirmasi_password" class="col-sm-2 col-form-label">Konfirmasi Password</label>
							    <div class="col-sm-10">
							      <input type="password" name="konfirmasi_password" id="konfirmasi_password" class="form-control <?php if ($errors->has('konfirmasi_password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('konfirmasi_password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Konfirmasi Password" required="required" value="<?php echo e(old('konfirmasi_password')); ?>">
                                      <?php if ($errors->has('konfirmasi_password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('konfirmasi_password'); ?>
                                    <span class="text-danger" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							    </div>
							  </div>

							  <div class="form-group row">
							    <div class="col-sm-12">
							      <button type="submit" value="submit" class="btn subs_btn form-control">register now</button>
							    </div>
							  </div>

							</form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--================End login Area =================-->
    <!--================login_part end =================-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('toko.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projek\htdocs\kpcok\resources\views/toko/pelanggan/register.blade.php ENDPATH**/ ?>