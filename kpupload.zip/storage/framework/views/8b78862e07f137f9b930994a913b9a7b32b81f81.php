<?php $__env->startSection('content'); ?>
	<!-- 404 page contain Start  -->
 <div id="404-page-contain">
   <div class="container">
     <div class="row">
       <div class="detail-404">
        	<div class="col-md-12 col-sm-12">
        		<h1>Upload Bukti Transfer Berhasil!</h1>
        		<p> Bukti pembayaran kamu sudah kami terima. kami akan segera memproses pesanan kamu.</p>
        	</div>
       </div>
     </div>
   </div>
 </div>
 <!-- 404 page contain end  -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('toko.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projek\htdocs\kpcok\resources\views/toko/transaksi/pembayaran/sukses.blade.php ENDPATH**/ ?>