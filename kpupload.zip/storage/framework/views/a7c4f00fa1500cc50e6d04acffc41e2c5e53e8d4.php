<?php $__env->startSection('content'); ?>
<?php
	$produk = $data['produk'];
?> 

 <!-- offer block Start  -->
<?php echo $__env->make('toko.layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- offer block end  --> 
<div id="product-category">
  <div class="container">
    

    <div class="row">
      <!-- left block Start  -->
      <?php echo $__env->make('toko.layouts.sidemenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>          
      <!-- left block end  --> 
      <form method="post" action="<?php echo e(url('produk/sort')); ?>">
        <?php echo csrf_field(); ?>
        <div class="shoring pull-right">
          <div class="short-by">
            <p>Sort By</p>
            <div class="select-item">
              <select name="sort">
                <option> -- Produk Terbaru -- </option>
                <option onclick="form.submit()" value="nama_produk asc">Nama (A to Z)</option>
                <option onclick="form.submit()" value="nama_produk desc">Nama (Z - A)</option>
                <option onclick="form.submit()" value="harga asc">Harga (low&gt;high)</option>
                <option onclick="form.submit()" value="harga desc">Harga(high &gt; low)</option>
              </select>
              <span class="fa fa-angle-down"></span> </div>
            </div>
          </div>
        </form>
      <div class="col-md-9 col-sm-8"> 

        <!-- right block Start  -->
        <div id="right">
          
              <div class="product-grid-view">
                <ul>
                  <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php
                    $nama_produk = $produk->nama_produk;
                    $nama_produk = str_replace(' ','_',$nama_produk)
                  ?>
                  <?php if($produk->stok-$produk->qty > 0): ?>
                  <li>
                    <div class="item col-md-4 col-sm-6 col-xs-6">
                      <div class="product-block ">
                        <div class="image"> <a href="<?php echo e(url('produk/'.$produk->id_produk.'/nama/'.$nama_produk)); ?>"><img class="img-responsive" title="T-shirt" alt="T-shirt" src="<?php echo e(asset($produk->gambar)); ?>"></a> </div>
                        <div class="product-details">
                          <div class="product-name">
                            <h4><a href="<?php echo e(url('produk/'.$produk->id_produk.'/nama/'.$nama_produk)); ?>"><?php echo e($produk->nama_produk); ?> </a></h4>
                          </div>
                          <div class="price"> Rp. <?php echo e(number_format($produk->harga,2,',','.')); ?> </div>
                          <div class="product-hov">
                            <?php if(Auth::user()): ?>
                            <ul>
                              <li class="addtocart"><a href="<?php echo e(url('keranjang/beli/'.$produk->id_produk)); ?>">Masukin Keranjang</a> </li>
                            </ul>
                            <?php else: ?>
                            <ul>
                              <li class="addtocart">Mau beli? Login dulu!</li>
                            </ul>
                            <?php endif; ?>
                            <div class="review"> <span class="rate"><strong> masih ada <?php echo e($produk->stok-$produk->qty); ?> barang </strong>  </span> </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </li>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </ul>
                </div>
              </div>

        
            <?php echo $data['produk']->render(); ?>

        <!-- right block end  --> 
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('toko.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projek\htdocs\kpcok\resources\views/toko/produk/index.blade.php ENDPATH**/ ?>