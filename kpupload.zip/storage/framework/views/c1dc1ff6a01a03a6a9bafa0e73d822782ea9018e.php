<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo e($title); ?>

      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo e(url('admin')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">User Admin</a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-8">
          <?php if(session()->get('success')): ?>
          <div class="alert alert-Success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <?php echo e(session()->get('success')); ?>  
          </div>
          <?php endif; ?>
          <div class="box box-success">
            <div class="box-header with-border">
              <h3 class="box-title">Data Admin</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-striped">
                <thead>
                <tr>
                  <th>#</th>
                  <th>Nama</th>
                  <th>Email</th>
                  <th>Role</th>
                  <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $user_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($user->id_user); ?></td>
                  <td><?php echo e($user->nama_depan." ".$user->nama_belakang); ?></td>
                  <td><?php echo e($user->email); ?></td>
                  <td><?php echo e($user->role); ?></td>
                  <td>
                    <?php if($user->id_user!=Auth::user()->id_user): ?>
                    <a href="<?php echo e(url('admin/useradmin/edit/'.$user->id_user)); ?>" class="btn btn-info">
                      <span class="fa fa-edit"></span>
                    </a>
                    <a onclick="return confirm('Apakah anda yakin untuk mengahapus data berikut');" href="<?php echo e(url('admin/useradmin/delete/'.$user->id_user)); ?>" class="btn btn-danger">
                      <span class="fa fa-trash"></span>
                    </a>
                    <?php endif; ?>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
            <div class="box-footer clearfix">
              
            </div>
          </div>
          <!-- /.box -->

          
          <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-4">
          <div class="box box-primary">
            <div class="box-header box-p with-border">
              <h3 class="box-title">Tambah Data Admin</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body no-padding">
              <form role="form" method="post" action="<?php echo e(url('admin/useradmin/save')); ?>">
                <?php echo csrf_field(); ?>
              <div class="box-body">
                <div class="form-group">
                  <label for="nama_depan">Nama Depan</label>
                  <input type="text" class="form-control <?php if ($errors->has('nama_depan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_depan'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nama_depan" id="nama_depan" placeholder="Nama depan" value="<?php echo e(old('nama_depan')); ?>" minlength="3" required="required">
                  <?php if ($errors->has('nama_depan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_depan'); ?>
                    <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                  
                </div>
                <div class="form-group">
                  <label for="nama_depan">Nama Belakang</label>
                  <input type="text" class="form-control <?php if ($errors->has('nama_belakang')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_belakang'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nama_belakang" id="nama_belakang" placeholder="Nama depan" value="<?php echo e(old('nama_belakang')); ?>" minlength="3" required="required">
                  <?php if ($errors->has('nama_belakang')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_belakang'); ?>
                    <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group">
                  <label for="email">Alamat Email</label>
                  <input type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" id="email" placeholder="email" value="<?php echo e(old('email')); ?>" required="required">
                  <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                    <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group">
                  <label for="role">Role Admin</label>
                  <select name="role" class="form-control" name="role" id="role" placeholder="Role Admin" required="required">
                    <option value="admin">Admin</option>
                    <option value="superadmin">Super Admin</option>
                  </select>
                </div>
                <div class="form-group">
                  <label for="password">Password</label>
                  <input type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" id="password" placeholder="Password" value="<?php echo e(old('password')); ?>" minlength="8" required="required">
                  <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                    <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group">
                  <label for="confirm_password">Konfirmasi Password</label>
                  <input type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="confirm_password" id="confirm_password" placeholder="konfirmasi password" minlength="8" required="required">
                  <?php if ($errors->has('confirm_password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('confirm_password'); ?>
                    <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <div class="pull-right box-tools">
                  <button type="submit" class="btn btn-success"><i class="fa fa-hdd-o"></i> Simpan </button>
                  <button type="reset" class="btn btn-warning"><i class="fa fa-eraser"></i> Reset </button>
                </div>
              </div>
            </form>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

          
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
     
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<script type="text/javascript">
  var password = document.getElementById("password")
  , confirm_password = document.getElementById("confirm_password");

  function validatePassword(){
    if(password.value != confirm_password.value) {
      confirm_password.setCustomValidity("Passwords Don't Match");
    } else {
      confirm_password.setCustomValidity('');
    }
  }

  password.onchange = validatePassword;
  confirm_password.onkeyup = validatePassword;
</script>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projek\htdocs\kpcok\resources\views/admin/useradmin/index.blade.php ENDPATH**/ ?>