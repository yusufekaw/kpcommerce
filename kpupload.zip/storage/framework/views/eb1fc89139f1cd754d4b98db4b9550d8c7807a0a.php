<?php $__env->startSection('content'); ?>

	<?php echo $__env->make('beautymail::templates.widgets.articleStart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<h2><?php echo e($nama_toko); ?> ! <small>Registrasi Berhasil</small></h2>
		<h5 class="secondary"><strong>Hai <?php echo e($name); ?>!</strong></h5>
		<p>Registrasi kamu berhasil</p>
		<p>Sekarang kamu bisa melanjutkan login untuk memulai belanja</p>

	<?php echo $__env->make('beautymail::templates.widgets.articleEnd', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('beautymail::templates.widgets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projek\htdocs\kpcok\resources\views/toko/mail/register.blade.php ENDPATH**/ ?>