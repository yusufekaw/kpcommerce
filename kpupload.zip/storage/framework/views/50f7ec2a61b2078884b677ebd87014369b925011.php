

<!-- Footer block Start  -->
 <footer id="footer">
   <div class="container">
    <br>
     <div class="row">
       <div class="col-md-3">
         <div class="about">
           <p><?php echo $data['toko']->tagline; ?></p>
         </div>
       </div>
       <div class="col-md-3">
         <div class="new-store">
           <h4>Bisa Bayar Pake</h4>
           <ul class="toggle-footer">
             <?php $__currentLoopData = $data['bank']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <li><a href="#"><img src="<?php echo e(asset($bank->logo)); ?>" style="width: 150px; height: 50px"></a></li>
             <br>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </ul>
         </div>
       </div>
       <div class="col-md-3">
         <div class="information">
           <h4>Bisa Kirim Lewat</h4>
           <ul class="toggle-footer">
            <li><img src="https://www.posindonesia.co.id/photos/1/Logo%20Pos%20Indonesia%20Kecil%20Warna%20Transparan.gif" style="width: 150px; height: 50px"></li>
            <br>
            <li><img src="https://www.jne.co.id/frontend/images/material/logo.jpg" style="width: 150px; height: 50px"></li>
            <br>
            <li><img src="https://www.tiki.id/images/logo/nav.png" style="width: 150px; height: 50px"></li>
           </ul>
         </div>
       </div>
       <div class="col-md-3">
         <div class="contact">
           <h4>Kontak Kami</h4>
           <ul class="toggle-footer">
            <?php $__currentLoopData = $data['kontak']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kontak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($kontak->urutan < 6 ): ?>
             <li>
              <div class="row">
                <div class="col-md-2"> <i class="fa <?php echo e($kontak->ikon); ?>"></i></div> 
                <div class="col-md-10"> <?php echo e($kontak->kontak_info); ?> </div>
              </div> 
             </li>
             <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </ul>
         </div>
       </div>
     </div>
   </div>
   <div class="footer-bottom">
     <div class="container">
       <div class="row">
         <div class="col-md-12">
           <div class="social-link">
             <ul>
              <?php $__currentLoopData = $data['kontak']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kontak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($kontak->urutan > 5 ): ?>
               <li><a href="<?php echo e($kontak->link); ?>" target="_blank"><i class="fa <?php echo e($kontak->ikon); ?>"></i></a></li>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </ul>
           </div>
         </div>
       </div>
       <div class="row">
         <div class="col-md-12">
           <div class="footer-link">
             <ul>
                <li><a href="<?php echo e(url('/')); ?>">Beranda</a></li>
              <?php $__currentLoopData = $data['halaman']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $halaman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
              $judul = $halaman->judul;
              $judul = str_replace(" ", "_", $judul)
              ?>
             <li><a href="<?php echo e(url('halaman/'.$halaman->id_halaman.'/judul/'.$judul)); ?>"><?php echo e($halaman->judul); ?></a></li>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <li><a href="<?php echo e(url('halaman/tentang')); ?>">Tentang Kami</a></li>
                <li><a href="<?php echo e(url('halaman/kontak')); ?>">Kontak Kami</a></li>
             </ul>
           </div>
         </div>
       </div>
       <div class="row">
         <div class="col-md-12">
           <div class="copy-right">
             <p> &copy; 2019. Yusuf Eka W.</p>
           </div>
         </div>
       </div>
     </div>
   </div>
 </footer>
 <!-- Footer block End  --> <?php /**PATH D:\projek\htdocs\kpupload\resources\views/toko/layouts/footer.blade.php ENDPATH**/ ?>