</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</div><?php /**PATH D:\projek\htdocs\kpcok\vendor\snowfire\beautymail\src\Snowfire\Beautymail/../../views/templates/minty/contentEnd.blade.php ENDPATH**/ ?>