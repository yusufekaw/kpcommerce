<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-sm-12">
		<div id="contact-page-contain">
		   <div class="container">
		    
		     
		     <div class="contact-submit">
		       <form method="post" action="<?php echo e(url('pelanggan/update/'.Auth::user()->id_user)); ?>">
		       	<?php echo csrf_field(); ?>
		         <div class="row">
		           <div class="col-md-6 col-sm-12">
		             <div class="input-group">
		             	<label class="form-control" >Nama Depan *</label>
		               <input type="text" name="nama_depan" value="<?php echo e(Auth::user()->nama_depan); ?>" class="form-control" required>
		               <?php if ($errors->has('nama_depan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_depan'); ?>
		               <p class="text-danger"><?php echo e($message); ?></p>
		               <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
		             </div>
		           </div>
		           <div class="col-md-6 col-sm-12">
		             <div class="input-group">
		             	<label class="form-control" >Nama Belakang *</label>
		               <input type="text" name="nama_belakang" value="<?php echo e(Auth::user()->nama_belakang); ?>" class="form-control" placeholder="Nama Belakang *" required>
		             </div>
		             <?php if ($errors->has('nama_depan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_depan'); ?>
		               <p class="text-danger"><?php echo e($message); ?></p>
		               <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
		           </div>
		           <div class="col-md-6 col-sm-12">
		             <div class="input-group">
		             	<label class="form-control" >Email *</label>
		               <input type="email" name="email" value="<?php echo e(Auth::user()->email); ?>" class="form-control" placeholder="Email *"  required>
		             </div>
		             <?php if ($errors->has('nama_depan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_depan'); ?>
		               <p class="text-danger"><?php echo e($message); ?></p>
		               <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
		           </div>
		           <div class="col-md-6 col-sm-12">
		             <div class="input-group">
		             <label class="form-control" >Jenis Kelamin *</label>
		               <label class="form-control">
		               		<input type="radio" name="gender" value="l" required> Laki-laki
		               		<input type="radio" name="gender" value="p" required> Perempuan
		               </label>
		             </div>
		             <?php if ($errors->has('nama_depan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_depan'); ?>
		               <p class="text-danger"><?php echo e($message); ?></p>
		               <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
		           </div>
		           <div class="col-md-12">
		             <div class="col-md-12 text-center">
		               <button class="btn btn-primary" type="submit"><i class="fa fa-hdd-o"></i> Update </button>
		             </div>
		           </div>
		         </div>
		       </form>
		     </div>
		     
		   </div>
		 </div>
	</div>
</div>
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('toko.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projek\htdocs\kpcok\resources\views/toko/pelanggan/edit.blade.php ENDPATH**/ ?>