<?php $__env->startSection('content'); ?>

<div id="product-category">
  <div class="container">
    <div class="row">
      <!-- left block Start  -->
      <?php echo $__env->make('toko.layouts.sidemenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>          
      <!-- left block end  --> 
      <div class="col-md-9 col-sm-8"> 
        <!-- right block Start  -->
        <div id="right">
          
              <div class="product-grid-view">
                <ul>
                  <?php $__currentLoopData = $produk_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li>
                    <div class="item col-md-4 col-sm-6 col-xs-6">
                      <div class="product-block ">
                        <div class="image"> <a href="<?php echo e(url('produk/'.$produk->id_produk)); ?>"><img class="img-responsive" title="T-shirt" alt="T-shirt" src="<?php echo e(asset($produk->gambar)); ?>"></a> </div>
                        <div class="product-details">
                          <div class="product-name">
                            <h4><a href="product-detail-view.html"><?php echo e($produk->nama_produk); ?> </a></h4>
                          </div>
                          <div class="price"> Rp.  <?php echo e($produk->harga); ?> </div>
                          <div class="product-hov">
                            <?php if(Auth::user()): ?>
                            <ul>
                              <li class="addtocart"><a href="<?php echo e(url('keranjang/beli/'.$produk->id_produk)); ?>">Masukin Keranjang</a> </li>
                            </ul>
                            <?php else: ?>
                            <ul>
                              <li class="addtocart">Mau beli? Login dulu!</li>
                            </ul>
                            <?php endif; ?>
                            <div class="review"> <span class="rate"><strong> masih ada <?php echo e($produk->stok); ?> barang </strong>  </span> </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </ul>
                </div>
              </div>
          <!--
          <div class="row">
            <div class="pagination-bar">
              <ul>
                <li><a href="#"><i class="fa fa-angle-left"></i></a></li>
                <li class="active"><a href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#"><i class="fa fa-angle-right"></i></a></li>
              </ul>
            </div>
          </div>
        -->
        <div class="row">
          <div class="pagination-bar">
            <ul>
              <li><?php echo e($produk_all->render()); ?></li>
            </ul>
          </div>
        </div>
        <!-- right block end  --> 
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('toko.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projek\htdocs\kpcok\resources\views/toko/index.blade.php ENDPATH**/ ?>