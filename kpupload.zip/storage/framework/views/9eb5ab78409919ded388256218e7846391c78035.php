<?php $__env->startSection('content'); ?>
<?php 
	$bayar=0;
	$ongkir=0;
  $metode_pengiriman = $data['metode_pengiriman']; 
  $order = $data['order']; 
  $id = $data['id']; 
?>
<!-- bredcrumb and page title block end  -->
  <div id="checkout-step-contain">
    <div class="container">

      <div class="row">
        <div class="col-lg-12">
          <h2 class="delivery-method tf">Order Riview</h2>
        </div>
        <div class="col-md-12">
          <div class="cart-content table-responsive">
            <table class="cart-table ">
              <tbody>
                <tr class="Cartproduct carttableheader">
                  <td style="width:10%"> Product</td>
                  <td style="width:45%">Details</td>
                  <td style="width:10%">QNT</td>
                  <td style="width:15%">Total</td>
                </tr>

                <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                  $nama_produk = $order->nama_produk;
                  $nama_produk = str_replace(' ','_',$nama_produk);
                ?>
                <tr class="Cartproduct">
                  <td ><div class="image"><a href="<?php echo e(url('produk/'.$order->id_produk.'/nama/'.$nama_produk)); ?>"><img alt="img" src="<?php echo e(url($order->gambar)); ?>"></a></div></td>
                  <td><div class="product-name">
                      <h3><a href="<?php echo e(url('produk/'.$order->id_produk.'/nama/'.$nama_produk)); ?>"><?php echo e($order->nama_produk); ?></a></h3>
                    </div>
                    <div class="price"><span>Rp. <?php echo e(number_format($order->harga,2,',','.')); ?></span></div></td>
                  <td class="product-quantity"><div class="quantity">
                      <?php echo e($order->qty); ?>

                    </div></td>
                  <td class="price">Rp. <?php echo e(number_format($order->total_harga,2,',','.')); ?></td>
                </tr>
                <?php 
                	$bayar+=$order->total_harga
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr class="cart-detail">
                  <td colspan="3">Total produk</td>
                  <td colspan="2" class="price">Rp. <?php echo e(number_format($bayar,2,',','.')); ?></td>
                </tr>
                <tr class="cart-detail">
                  <td colspan="3">Ongkir</td>
                  <?php $__currentLoopData = $metode_pengiriman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metode_pengiriman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <td colspan="2" class="price"><span class="success">Rp. <?php echo e(number_format( $metode_pengiriman->tarif,2,',','.')); ?></span></td>
                  <?php
                  	$ongkir+=$metode_pengiriman->tarif;
                  ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                <tr class="cart-detail">
                  <td colspan="3"> Total</td>
                  <td colspan="2" class="price" id="total-price">Rp. <?php echo e(number_format($bayar+$ongkir,2,',','.')); ?></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div class="col-xs-12 col-sm-12">
          <div class="cart-bottom">
            <div class="box-footer">
              <div class="pull-left"><a href="<?php echo e(url('/')); ?>" class="btn btn-default"> <i class="fa fa-arrow-left"></i> &nbsp; Belanja lagi </a></div>
              <div class="pull-right">
              	<form method="post" action="<?php echo e(url('order/konfirmasi/kirim/'.$id)); ?>">
              		<?php echo csrf_field(); ?>
              		<input type="hidden" name="id_order" value="<?php echo e($id); ?>">
                  <input type="hidden" name="status" value="memesan">
              		<input type="hidden" name="kode_status" value=2>
              	<button class="btn btn-primary btn-small " type="submit"> Konfirmasi Order &nbsp; <i class="fa fa-check"></i> </button>
              	</form> 
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('toko.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projek\htdocs\kpupload\resources\views/toko/transaksi/order/konfirmasi.blade.php ENDPATH**/ ?>