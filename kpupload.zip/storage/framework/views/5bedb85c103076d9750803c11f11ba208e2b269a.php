<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo e($data['title']); ?></title>
<meta content="" name="description">
<meta content="" name="author">
<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('kors-look/images/favicon.ico')); ?>">
<link rel="icon" type="image/png" href="<?php echo e(asset('kors-look/images/favicon.png')); ?>">
<link rel="apple-touch-icon" href="<?php echo e(asset('kors-look/images/favicon.png')); ?>">
<link href="<?php echo e(asset('kors-look/css/jquery-ui.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('kors-look/bootstrap/css/bootstrap.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('kors-look/css/style.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('kors-look/css/font-awesome.css')); ?>" rel="stylesheet" type="text/css">
<link href='https://fonts.googleapis.com/css?family=Poppins:400,500,600,300,700' rel='stylesheet' type='text/css'>
<link href="<?php echo e(asset('kors-look/css/owl.carousel.css')); ?>" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('kors-look/css/smoothproducts.css')); ?>">
<style type="text/css">
  
@import  url(//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css);

fieldset, label { margin: 0; padding: 0; }

/****** Style Star Rating Widget *****/

.rating { 
  border: none;
  float: left;
}

.rating > input { display: none; } 
.rating > label:before { 
  margin: 5px;
  font-size: 1.25em;
  font-family: FontAwesome;
  display: inline-block;
  content: "\f005";
}

.rating > .half:before { 
  content: "\f089";
  position: absolute;
}

.rating > label { 
  color: #ddd; 
 float: right; 
}

/***** CSS Magic to Highlight Stars on Hover *****/

.rating > input:checked ~ label, /* show gold star when clicked */
.rating:not(:checked) > label:hover, /* hover current star */
.rating:not(:checked) > label:hover ~ label { color: #FFD700;  } /* hover previous stars in list */

.rating > input:checked + label:hover, /* hover current star when changing rating */
.rating > input:checked ~ label:hover,
.rating > label:hover ~ input:checked ~ label, /* lighten current selection */
.rating > input:checked ~ label:hover ~ label { color: #FFED85;  } 

</style>

</head>
<body>
<?php
  $produk= $data['produk'];
  $gambar_produk=  $data['gambar_produk'];
  $di_keranjang = $data['di_keranjang'];
  $komentar = $data['komentar'];
  $order_count = $data['order_count'];
  $rating_count = $data['rating_count'];
  $rating_counter = $data['rating_counter'];
  $rating_sum = $data['rating_sum'];
  $rating_value = $data['rating_value'];
  $rate = "";
?>
<div class="wrapar"> 
  <!-- Header Start-->
  <?php echo $__env->make('toko.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- Header End --> 
  
  <!-- Main menu Start -->
  
  <!-- Main menu End --> 
  <?php echo $__env->make('toko.layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- offer block Start  -->
  <?php echo $__env->make('toko.layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- offer block end  --> 
  
 
  <div id="product-category">
    <div class="container">
      <div class="row">
      <?php echo $__env->make('toko.layouts.sidemenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="col-md-9 col-sm-8"> 
          <!-- right block Start  -->
          <div id="right">
            <div class="product-detail-view">
              <div class="row">
                <div class="col-md-6">
                  <div class="sp-loading"><img src="images/sp-loading.gif" alt=""><br>
                    LOADING IMAGES</div>
                  <div class="sp-wrap">
                    <?php $__currentLoopData = $gambar_produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gambar_produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="item" href="<?php echo e(url($gambar_produk->path)); ?>">
                      <img src="<?php echo e(asset($gambar_produk->path)); ?>" alt="">
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </div>
                <div class="col-md-6">
                  
                  <div class="product-detail-content">

                    <div class="product-name">
                      <h4><a href="product-detail-view.html"><?php echo e($produk->nama_produk); ?> </a></h4>
                      <?php if(Auth::user()): ?>
                      <?php if($order_count>0 && $rating_count==0): ?>

                      <form method="post" action="<?php echo e(url('produk/rating')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id_user" value="<?php echo e(Auth::user()->id_user); ?>">
                        <input type="hidden" name="id_produk" value="<?php echo e($produk->id_produk); ?>">
                        <fieldset class="rating">

                          <input type="radio" id="star5" name="rating" value="5" onclick="form.submit()" />
                          <label class = "full" for="star5" title="Awesome - 5 stars"></label>
                          <input type="radio" id="star4" name="rating" value="4" onclick="form.submit()" />
                          <label class = "full" for="star4" title="Pretty good - 4 stars"></label>
                          <input type="radio" id="star3" name="rating" value="3" onclick="form.submit()" />
                          <label class = "full" for="star3" title="Meh - 3 stars"></label>
                          <input type="radio" id="star2" name="rating" value="2" onclick="form.submit()" />
                          <label class = "full" for="star2" title="Kinda bad - 2 stars"></label>
                          <input type="radio" id="star1" name="rating" value="1" onclick="form.submit()"/>
                          <label class = "full" for="star1" title="Sucks big time - 1 star"></label>
                        </fieldset>
                      </form>
                        
                      <?php endif; ?>
                      <?php endif; ?>
                    </div>
                    <div class="review"> 
                      <span class="rate">
                      <?php for($i=0; $i<$rating_value; $i++): ?> 
                        <i class="fa fa-star rated"></i>
                      <?php endfor; ?>
                      <?php if($rating_value>0): ?>
                      <?php echo e($rating_value); ?>

                      <?php endif; ?>
                      </span>
                      
                    </div>
                      
                      <br/>
                    <div class="price"> <span class="price-new">Rp. <?php echo e(number_format($produk->harga,2,',','.')); ?></span> </div>
                    <div class="stock"><span>Stok : </span><?php echo e($produk->stok-$di_keranjang); ?> </div>
                    <div class="products-code"> <span>Kode Produk :</span> <?php echo e($produk->id_produk); ?></div>
                    <form method="post" action="<?php echo e(url('keranjang/beli')); ?>">
                    <div class="product-qty">
                      <label for="qty">Quantity :</label>
                      <div class="custom-qty">
                        <button onclick="var result = document.getElementById('qty'); var qty = result.value; if( !isNaN( qty ) &amp;&amp; qty &gt; 1 ) result.value--;return false;" class="reduced items" type="button"> <i class="fa fa-minus"></i> </button>
                        <input type="text" class="input-text qty" title="Qty" value="1" maxlength="3" max="<?php echo e($produk->stok); ?>" id="qty" name="qty">
                        <button onclick="var result = document.getElementById('qty'); var qty = result.value; if( !isNaN( qty )) result.value++;return false;" class="increase items" type="button"> <i class="fa fa-plus"></i> </button>
                      </div>
                    </div>
                    <div class="add-to-cart">
                      
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id_produk" value="<?php echo e($produk->id_produk); ?>">
                        <input type="hidden" name="max_qty" value="<?php echo e($produk->stok-$di_keranjang); ?>">
                        <?php if(Auth::user()): ?>
                        <button type="submit" class="btn btn-default">Masukkin Keranjang</button>
                        <?php else: ?>
                        <h4>Mau beli? Login dulu!</h4>
                        <?php endif; ?>

                    </div>
                      </form>

                  </div>
                </div>
              </div>
            </div>
            

            <div class="product-detail-tab">
              <div class="row">
                <div class="col-md-12">
                  <div id="tabs">
                    <ul class="nav nav-tabs">
                      <li><a class="tab-Description selected" title="Description">Deskripsi</a></li>
                      <li><a class="tab-Product-Tags" title="Product-Tags">Komentar</a></li>
                    </ul>
                  </div>
                  <div id="items">
                    <div class="tab-content">
                      <ul>
                        <li>
                          <div class="items-Description selected">
                            <div class="Description"> 
                              <?php echo $produk->deskripsi; ?>

                            </div>
                          </div>
                        </li>
                        <li>
                          <div class="items-Product-Tags contact-submit">
                            <table class="table table-responsive table-stripped">
                              <?php $__currentLoopData = $komentar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komentar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td><i class="fa fa-users"></i> <?php echo e($komentar->role); ?></td>
                                <td><i class="fa fa-user"></i> <?php echo e($komentar->nama); ?></td>
                                <td><i class="fa fa-calendar"></i> <?php echo e($komentar->tanggal); ?></td>
                              </tr>
                              <tr>
                                <td colspan="3"><?php echo e($komentar->komentar); ?></td>
                              </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                            <?php if(Auth::user()): ?>
                            <form method="post" action="<?php echo e(url('produk/komentar')); ?>">
                              <?php echo csrf_field(); ?>
                              <div class="input-group">
                                <input type="hidden" name="id_user" value="<?php echo e(Auth::user()->id_user); ?>">
                                <input type="hidden" name="id_produk" value="<?php echo e($produk->id_produk); ?>">
                                <input type="hidden" name="kode_status" value="1">
                                <input type="hidden" name="status" value="terkirim">
                                <textarea name="komentar" class="form-control" name="contact-message" id="textarea_message" placeholder="Message *" required></textarea>
                              </div>
                              <button type="submit" class="btn btn-default" name="kirim"> kirim Komentar </button>
                            </form>
                            <?php echo $data['komentar']->render(); ?>

                            <?php endif; ?>
                          </div>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!--div class="product-detail-tab">
              <div class="row">
                <div class="col-md-12">
                  <div id="tabs">
                    <ul class="nav nav-tabs">
                      <li><a class="tab-Description selected" title="Description">Description</a></li>
                      <li><a class="tab-Komentar" title="Komentar">Description</a></li>
                      
                    </ul>
                  </div>
                  <div id="items">
                    <div class="tab-content">
                      <ul>
                        <li>
                          <div class="items-Description selected">
                            <div class="Description"> <?php echo $produk->deskripsi; ?> </div>
                          </div>
                        </li>
                        <li>
                          <div class="items-Komentar">
                            <div class="Description"> 

                            </div>
                          </div>
                        </li>
                        
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div-->
          </div>
          <!-- right block end  --> 
        </div>
      </div>
    </div>
  </div>
  
  <!-- Footer block Start  -->
  <?php echo $__env->make('toko.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- Footer block End  --> 
</div>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="<?php echo e(asset('kors-look/js/jQuery.js')); ?>"></script> 
<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="<?php echo e(asset('kors-look/bootstrap/js/bootstrap.js')); ?>"></script> 
<script src="<?php echo e(asset('kors-look/js/jquery-ui.js')); ?>"></script> 
<script src="<?php echo e(asset('kors-look/js/owl.carousel.min.js')); ?>"></script> 
<script src="<?php echo e(asset('kors-look/js/globle.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(asset('kors-look/js/smoothproducts.min.js')); ?>"></script> 
<!-- product tab js --> 

<script type="text/javascript"> 
      $("#tabs li a").click(function(e){
        var title = $(e.currentTarget).attr("title");
        $("#tabs li a").removeClass("selected")
        $(".tab-content li div").removeClass("selected")
        $(".tab-"+title).addClass("selected")
        $(".items-"+title).addClass("selected")
        $("#items").attr("class","tab-"+title);
      });
        $(window).load( function() {
        $('.sp-wrap').smoothproducts();
    });
     </script>
<script src="<?php echo e(asset('kors-look/js/globle.js')); ?>"></script>
</body>
</html><?php /**PATH D:\projek\htdocs\kpupload\resources\views/toko/produk/detail.blade.php ENDPATH**/ ?>