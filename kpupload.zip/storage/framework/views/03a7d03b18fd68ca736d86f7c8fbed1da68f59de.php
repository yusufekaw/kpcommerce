<?php $__env->startSection('content'); ?>

<?php
$useradmin = $data['useradmin'];
?>

<style type="text/css">
	.upload-btn-wrapper {
  position: relative;
  overflow: hidden;
  display: inline-block;
}

.upload-btn-wrapper input[type=file] {
  font-size: 100px;
  position: absolute;
  left: 0;
  top: 0;
  opacity: 0;
}
</style>

<div class="right_col" role="main">
  <div class="page-title">
    <div class="title_left">
      <h3>User Admin</h3>
    </div>
  </div>

  <div class="clearfix"></div>
 
<div class="row">
	<div class="col-md-12 col-sm-12">
		<?php if(session()->get('success')): ?>
		<div class="alert alert-success alert-dismissible">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			<?php echo e(session()->get('success')); ?>  
		</div>
		<?php endif; ?>
		<div class="x_panel">
		  <div class="x_title">
		    <h2>Detail User Admin</h2>
		    <ul class="nav navbar-right panel_toolbox">
		      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
		      </li>
		      <li class="dropdown">
		        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
		        <ul class="dropdown-menu" role="menu">
		          <li><a href="#">Settings 1</a>
		          </li>
		          <li><a href="#">Settings 2</a>
		          </li>
		        </ul>
		      </li>
		      <li><a class="close-link"><i class="fa fa-close"></i></a>
		      </li>
		    </ul>
		    <div class="clearfix"></div>
		  </div>
		  <div class="x_content">
		  	<div class="pull-right">
		  		<a href="<?php echo e(url('admin/useradmin/edit/'.$useradmin->id_user)); ?>" class="btn btn-warning"><i class="fa fa-edit"></i> Ubah Profil</a>
		  		<?php if(AUth::user()->id_user != $useradmin->id_user): ?>
		  		<a href="<?php echo e(url('admin/useradmin/edit/password/'.$useradmin->id_user)); ?>" class="btn btn-warning"><i class="fa fa-pencil"></i> Ganti Password</a>
		  		<?php else: ?>
		  		<a href="<?php echo e(url('admin/profil/edit/password/'.$useradmin->id_user)); ?>" class="btn btn-warning"><i class="fa fa-pencil"></i> Ganti Password</a>
		  		<?php endif; ?>
		  	</div>
		  	<div class="row">
		  		<div class="col-md-4 col-sm-12">
		  			
		  			<img src="<?php echo e(asset($useradmin->avatar)); ?>" style="max-width: 100%; max-height: 100%;">
		  			<form method="post" action="<?php echo e(url('admin/useradmin/avatar/update/'.$useradmin->id_user)); ?>" enctype="multipart/form-data">
		  				<?php echo csrf_field(); ?>
		  			<label class="btn"> Ganti foto
		  				<input type="file" name="avatar" style="visibility: hidden;" onchange="form.submit();">
		  			</label>
		  			</form>
		  		</div>
		  		<div  class="col-md-8 col-sm-12">
		  			<table class="table table-responsive table-striped">
		  				<tr>
		  					<th>Nama</th>
		  					<td><?php echo e($useradmin->nama_depan.' '.$useradmin->nama_belakang); ?></td>
		  				</tr>
		  				<tr>
		  					<th>Email</th>
		  					<td><?php echo e($useradmin->email); ?></td>
		  				</tr>
		  				<tr>
		  					<th>Role</th>
		  					<td><?php echo e($useradmin->role); ?></td>
		  				</tr>
		  				<tr>
		  					<th>gender</th>
		  					<td>
		  						<?php if($useradmin->gender == 'l'): ?>
		  						Laki-laki
		  						<?php else: ?>
		  						Perempuan
		  						<?php endif; ?>
		  					</td>
		  				</tr>
		  			</table>	
		  		</div>
		  	</div>		 
		  </div>
		</div>
	</div>
</div>

</div>

<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projek\htdocs\kpcok\resources\views/admin/user/login/detail.blade.php ENDPATH**/ ?>