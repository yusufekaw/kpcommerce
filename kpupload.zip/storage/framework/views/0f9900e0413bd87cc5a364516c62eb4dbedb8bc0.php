<?php $__env->startSection('content'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('datatable/datatables.min.css')); ?>"/>
 
<script type="text/javascript" src="<?php echo e(asset('datatable/datatables.min.js')); ?>"></script>
<?php
  $alamat = $data['alamat'];
  $order = $data['order'];
?>

 <?php echo $__env->make('toko.layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12 col-sm-8"> 
          <!-- right block Start  -->
          <div id="right">
            <div class="product-detail-view">
              <div class="row">
                <div class="col-md-2">
                  <img src="<?php echo e(asset(Auth::user()->avatar)); ?>" class="img-fluid img-thumbnail">
                  <form method="post" action="<?php echo e(url('pelanggan/ganti_foto')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                  <label class="btn btn-default btn-block"><span class="fa fa-image"></span> Ganti Foto               
                    <input type="file" name="avatar" class="btn btn-default" style="display: none" onchange="form.submit()">
                  </label>
                  </form>
                  <a class="btn btn-default btn-block" href="<?php echo e(url('pelanggan/edit')); ?>">
                    <span class="fa fa-edit"></span> Ganti Profil
                  </a>
                  <a class="btn btn-default btn-block" href="<?php echo e(url('pelanggan/edit/password')); ?>">
                    <span class="fa fa-edit"></span> Ganti Password
                  </a>
                  <a class="btn btn-default btn-block" href="<?php echo e(url('pelanggan/alamat/tambah')); ?>">
                    <span class="fa fa-plus"></span> Tambah Alamat
                  </a>
                </div>
                <div class="col-md-10">
                    <div class="product-detail-tab">
                      <div class="row">
                        <div class="col-md-12">
                          <div id="tabs">
                            <ul class="nav nav-tabs">
                              <li><a class="tab-Description selected" title="Description">Profil</a></li>
                              <li><a class="tab-Product-Tags" title="Product-Tags">Alamat</a></li>
                              <li><a class="tab-Reviews" title="Reviews">Order</a></li>
                            </ul>
                          </div>
                          <div id="items">
                            <div class="tab-content">
                              <ul>
                                <li>
                                  <div class="items-Description selected">
                                    <div class="Description">
                                      <table class="table table-stripped table-responsive">
                                        <tbody>
                                          <tr>
                                            <th> Nama </th>
                                            <td> &nbsp; </td>
                                            <td> &nbsp;<?php echo e(Auth::user()->nama_depan.' '.Auth::user()->nama_belakang); ?> </td>
                                          </tr>
                                          <tr>
                                            <th> Email </th>
                                            <td> &nbsp; </td>
                                            <td> &nbsp;<?php echo e(Auth::user()->email); ?> </td>
                                          </tr>
                                          <tr>
                                            <th> Jenis Kelamin </th>
                                            <td> &nbsp; </td>
                                            <td>
                                              &nbsp;
                                              <?php if(Auth::user()->gender == 'l'): ?>
                                                Laki-laki
                                              <?php else: ?>
                                                Perempuan
                                              <?php endif; ?>
                                            </td>
                                          </tr>
                                        </tbody>
                                      </table> 
                                    </div>
                                  </div>
                                </li>
                                <li>
                                  <div class="items-Product-Tags ">
                                    <table class="table table-stripped table-responsive">
                                      <tbody>
                                        <?php $__currentLoopData = $alamat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alamat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>

                                          <?php if($alamat->jalan==null): ?>
                                          <td>
                                            <span class="fa fa-user"></span>&nbsp;&nbsp;&nbsp; 
                                            <?php echo e($alamat->atas_nama.' ('.$alamat->jenis.')'); ?>  
                                            <br> 
                                            <span class="fa fa-map-marker"></span>&nbsp;&nbsp;&nbsp; 
                                            <?php echo e($alamat->kelurahan); ?> RT/RW <?php echo e($alamat->rt.'/'.$alamat->rw); ?>

                                            kec. <?php echo e($alamat->kecamatan); ?>, <?php echo e($alamat->kota); ?>, <?php echo e($alamat->provinsi); ?>. <?php echo e($alamat->kodepos); ?>

                                            <br> 
                                            <span  class="fa fa-phone"></span> &nbsp;<?php echo e($alamat->telp); ?>


                                          </td>
                                          <?php else: ?>
                                          <td>
                                            <span class="fa fa-user"></span>&nbsp;&nbsp;&nbsp;
                                            <?php echo e($alamat->atas_nama.' ('.$alamat->jenis.')'); ?>  
                                            <br> 
                                            <span class="fa fa-map-marker"></span>&nbsp;&nbsp;&nbsp;
                                            <?php echo e($alamat->jalan); ?>, <?php echo e($alamat->kelurahan); ?> RT/RW <?php echo e($alamat->rt.'/'.$alamat->rw); ?>

                                            kec. <?php echo e($alamat->kecamatan); ?>, <?php echo e($alamat->nama_kota); ?>, <?php echo e($alamat->nama_provinsi); ?>. <?php echo e($alamat->kodepos); ?>

                                            <br> 
                                            <span  class="fa fa-phone"></span> &nbsp;&nbsp;&nbsp;<?php echo e($alamat->telp); ?>

                                          </td>
                                          <?php endif; ?>
                                          <td>
                                            <a class="btn btn-sm btn-warning" href="<?php echo e(url('pelanggan/alamat/edit/'.$alamat->id_alamat)); ?>">
                                              <i class="fa fa-edit"></i>
                                            </a>
                                            <a class="btn btn-sm btn-danger" href="<?php echo e(url('pelanggan/alamat/delete/'.$alamat->id_alamat)); ?>" onclick="confirm('yakin hapus alamat ini?');">
                                              <span class="fa fa-trash"></span>
                                            </a>
                                          </td>

                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </tbody>
                                    </table>
                                  </div>
                                </li>
                                <li>
                                  <div class="items-Reviews" id="example">
                                    <table class="table table-stripped table-responsive">
                                        <thead>
                                          <tr>
                                            <th>ID</th>
                                            <th>Status</th>
                                            <th>Tanggal</th>
                                          </tr>
                                        </thead>
                                        <tbody>
                                         <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <tr>
                                           <td>
                                            <a href="<?php echo e(url('order/detail/'.$order->id_order)); ?>">
                                              <?php echo e($order->id_order); ?>

                                            </a>
                                          </td>
                                           <td><?php echo e($order->status); ?></td>
                                           <td><?php echo e($order->created_at); ?></td>
                                         </tr>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        <tfoot>
                                          <tr>
                                            <th>ID</th>
                                            <th>Status</th>
                                            <th>Tanggal</th>
                                          </tr>
                                        </tfoot>
                                      </table> 
                                  </div>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                </div>
              </div>
            </div>
            &nbsp;
            

            

          </div>
          <!-- right block end  --> 
      </div>
    </div>
</div>         
<?php $__env->stopSection(); ?>

<script type="text/javascript"> 
      $("#tabs li a").click(function(e){
        var title = $(e.currentTarget).attr("title");
        $("#tabs li a").removeClass("selected")
        $(".tab-content li div").removeClass("selected")
        $(".tab-"+title).addClass("selected")
        $(".items-"+title).addClass("selected")
        $("#items").attr("class","tab-"+title);
      });
          $(window).load( function() {
        $('.sp-wrap').smoothproducts();
    });
     </script>

<script type="text/javascript">
  $(document).ready(function() {
      // Setup - add a text input to each footer cell
      $('#example tfoot th').each( function () {
          var title = $(this).text();
          $(this).html( '<input type="text" placeholder="Search '+title+'" />' );
      } );
   
      // DataTable
      var table = $('#example').DataTable();
   
      // Apply the search
      table.columns().every( function () {
          var that = this;
   
          $( 'input', this.footer() ).on( 'keyup change clear', function () {
              if ( that.search() !== this.value ) {
                  that
                      .search( this.value )
                      .draw();
              }
          } );
      } );
  } );
</script>
<?php echo $__env->make('toko.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projek\htdocs\kpupload\resources\views/toko/pelanggan/index.blade.php ENDPATH**/ ?>