<?php $__env->startSection('content'); ?>

<!-- 404 page contain Start  -->
 <div id="404-page-contain">
   <div class="container">
     <div class="row">
       <div class="detail-404">
         <div class="col-md-6 col-sm-6">
           <div class="text-404"> <a href="#"><img src="<?php echo e(asset('kors-look/images/404.png')); ?>" alt="404" title="404" class="img-responsive"></a> </div>
         </div>
         <div class="col-md-6 col-sm-6">
           <div class="error"> <a href="#"><img src="images/error.png" alt="404" title="404" class="img-responsive"></a>
             <p>Halaman gak ditemukan! coba cek lagi URL yang kamu masukin!</p>
             <a class="btn btn-large btn-primary" href="<?php echo e(url('/')); ?>" >Kembali Ke Beranda</a>
           </div>
         </div>
       </div>
     </div>
   </div>
 </div>
 <!-- 404 page contain end  --> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('toko.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projek\htdocs\kpcok\resources\views/toko/404.blade.php ENDPATH**/ ?>