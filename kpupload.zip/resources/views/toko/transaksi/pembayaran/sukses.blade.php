@extends('toko.layouts.app')
@section('content')
	<!-- 404 page contain Start  -->
 <div id="404-page-contain">
   <div class="container">
     <div class="row">
       <div class="detail-404">
        	<div class="col-md-12 col-sm-12">
        		<h1>Upload Bukti Transfer Berhasil!</h1>
        		<p> Bukti pembayaran kamu sudah kami terima. kami akan segera memproses pesanan kamu.</p>
        	</div>
       </div>
     </div>
   </div>
 </div>
 <!-- 404 page contain end  -->
@endsection