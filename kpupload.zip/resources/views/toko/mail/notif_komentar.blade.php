<h1>Hi, {{ $name }}!</h1>
<p>Komentar kamu sudah terkirim. Kami akan segera membalas komentar kamu</p>