<h1>Hi, {{ $name }}!</h1>
<p>Pesanan kamu sudah kami kirim. Semoga selamat sampai tujuan</p>