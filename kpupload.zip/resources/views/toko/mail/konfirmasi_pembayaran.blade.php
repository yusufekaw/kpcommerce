<h1>Hi, {{ $name }}!</h1>
<p>Bukti transfer kamu udah kami terima. Kami akan segera memproses pesanan kamu.</p>