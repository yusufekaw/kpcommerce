<h1>Hi, {{ $name }}!</h1>
<p>Bukti pembayaran kamu gak valid. Kalau kamu udah merasa bayar, coba upload ulang bukti pembayaran kamu</p>