<h1>Hi, {{ $name }}!</h1>
<p>Pesanan kamu sudah kami packing. Selanjutnya tinggal kami kirim ke kamu sesuai permintaan</p>