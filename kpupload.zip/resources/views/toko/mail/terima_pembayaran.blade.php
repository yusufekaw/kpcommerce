<h1>Hi, {{ $name }}!</h1>
<p>Bukti pembayaran kamu valid. Kami akan segera memroses pesanan kamu</p>