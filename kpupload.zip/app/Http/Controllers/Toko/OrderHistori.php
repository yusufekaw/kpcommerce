<?php

namespace App\Http\Controllers\Toko;

//use App\OrderHistori;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class OrderHistori extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\OrderHistori  $orderHistori
     * @return \Illuminate\Http\Response
     */
    public function show(OrderHistori $orderHistori)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\OrderHistori  $orderHistori
     * @return \Illuminate\Http\Response
     */
    public function edit(OrderHistori $orderHistori)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\OrderHistori  $orderHistori
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, OrderHistori $orderHistori)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\OrderHistori  $orderHistori
     * @return \Illuminate\Http\Response
     */
    public function destroy(OrderHistori $orderHistori)
    {
        //
    }
}
