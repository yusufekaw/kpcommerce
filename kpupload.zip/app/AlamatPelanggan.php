<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AlamatPelanggan extends Model
{
    //
}
